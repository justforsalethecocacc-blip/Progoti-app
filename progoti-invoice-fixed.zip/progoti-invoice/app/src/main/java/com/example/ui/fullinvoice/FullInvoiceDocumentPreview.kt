package com.example.ui.fullinvoice

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FullInvoiceEntity
import com.example.util.InvoicePdfGenerator
import com.example.viewmodel.FullInvoiceTotals

@Composable
fun FullInvoiceDocumentPreview(
    invoice: FullInvoiceEntity,
    totals: FullInvoiceTotals,
    modifier: Modifier = Modifier,
    onCopyToggle: ((String, Boolean) -> Unit)? = null
) {
    val context = LocalContext.current

    Column(modifier = modifier.fillMaxWidth().testTag("full_invoice_document_preview")) {
        if (onCopyToggle != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                PreviewCopyCheckbox("Original", invoice.copyOriginal) { onCopyToggle("original", it) }
                PreviewCopyCheckbox("Duplicate", invoice.copyDuplicate) { onCopyToggle("duplicate", it) }
                PreviewCopyCheckbox("Seller", invoice.copySeller) { onCopyToggle("seller", it) }
                PreviewCopyCheckbox("Transporter", invoice.copyTransporter) { onCopyToggle("transporter", it) }
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White)
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(595f / 842f)
            ) {
                val scaleX = size.width / 595f
                val scaleY = size.height / 842f

                drawContext.canvas.nativeCanvas.apply {
                    save()
                    scale(scaleX, scaleY)
                    InvoicePdfGenerator.drawTaxInvoicePage(context, this, invoice)
                    restore()
                }
            }
        }
    }
}

@Composable
private fun PreviewCopyCheckbox(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.clickable { onCheckedChange(!checked) },
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(12.dp)
                .border(1.dp, Color.Black)
                .background(Color.White),
            contentAlignment = Alignment.Center
        ) {
            if (checked) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = null,
                    tint = Color.Black,
                    modifier = Modifier.size(10.dp)
                )
            }
        }
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = label,
            fontSize = 9.sp,
            color = Color.Black
        )
    }
}
