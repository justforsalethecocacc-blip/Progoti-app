package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AppDatabase
import com.example.data.model.EstimateItem
import com.example.data.model.FullInvoiceEntity
import com.example.data.model.InvoiceItem
import com.example.data.model.SimpleEstimateEntity
import com.example.data.repository.InvoiceRepository
import com.example.util.IndianCurrencyWordConverter
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlin.math.roundToLong

data class FullInvoiceTotals(
    val itemsTotal: Double = 0.0,
    val taxableValue: Double = 0.0,
    val cgstAmount: Double = 0.0,
    val sgstAmount: Double = 0.0,
    val igstAmount: Double = 0.0,
    val totalTax: Double = 0.0,
    val roundedOff: Double = 0.0,
    val finalTotal: Double = 0.0,
    val words: String = "Zero Only"
)

class InvoiceViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: InvoiceRepository

    val savedFullInvoices: StateFlow<List<FullInvoiceEntity>>
    val savedSimpleEstimates: StateFlow<List<SimpleEstimateEntity>>

    init {
        val db = AppDatabase.getDatabase(application)
        repository = InvoiceRepository(db.invoiceDao())
        savedFullInvoices = repository.allFullInvoices.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )
        savedSimpleEstimates = repository.allSimpleEstimates.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )
    }

    // FULL INVOICE STATE
    private val _currentInvoiceId = MutableStateFlow<Long?>(null)
    val currentInvoiceId: StateFlow<Long?> = _currentInvoiceId.asStateFlow()

    private val _fullInvoice = MutableStateFlow(
        FullInvoiceEntity(
            invoiceDate = IndianCurrencyWordConverter.getCurrentDateIso(),
            challanDate = IndianCurrencyWordConverter.getCurrentDateIso(),
            orderDate = IndianCurrencyWordConverter.getCurrentDateIso()
        )
    )
    val fullInvoice: StateFlow<FullInvoiceEntity> = _fullInvoice.asStateFlow()

    private val _fullInvoiceItems = MutableStateFlow(listOf(InvoiceItem()))
    val fullInvoiceItems: StateFlow<List<InvoiceItem>> = _fullInvoiceItems.asStateFlow()

    // FULL INVOICE METHODS
    fun updateFullInvoiceField(transform: (FullInvoiceEntity) -> FullInvoiceEntity) {
        _fullInvoice.value = transform(_fullInvoice.value)
    }

    fun addFullInvoiceItem() {
        if (_fullInvoiceItems.value.size < 15) {
            _fullInvoiceItems.value = _fullInvoiceItems.value + InvoiceItem(id = System.currentTimeMillis())
        }
    }

    fun removeFullInvoiceItem(id: Long) {
        if (_fullInvoiceItems.value.size > 1) {
            _fullInvoiceItems.value = _fullInvoiceItems.value.filter { it.id != id }
        }
    }

    fun updateFullInvoiceItem(id: Long, qty: String? = null, desc: String? = null, hsn: String? = null, rate: String? = null) {
        _fullInvoiceItems.value = _fullInvoiceItems.value.map { item ->
            if (item.id == id) {
                val newQty = qty ?: item.quantity
                val newDesc = desc ?: item.description
                val newHsn = hsn ?: item.hsnCode
                val newRate = rate ?: item.rate

                val q = newQty.toDoubleOrNull() ?: 0.0
                val r = newRate.toDoubleOrNull() ?: 0.0
                val newAmount = if (q > 0 && r > 0) q * r else 0.0

                item.copy(
                    quantity = newQty,
                    description = newDesc,
                    hsnCode = newHsn,
                    rate = newRate,
                    amount = newAmount
                )
            } else item
        }
    }

    fun appendMmToItem(id: Long) {
        _fullInvoiceItems.value = _fullInvoiceItems.value.map { item ->
            if (item.id == id) {
                item.copy(description = item.description + "mm")
            } else item
        }
    }

    fun getFullInvoiceTotals(): FullInvoiceTotals {
        val inv = _fullInvoice.value
        val itemsTotal = _fullInvoiceItems.value.sumOf { it.amount }
        val taxableValue = itemsTotal + inv.labourCharges
        val cgstAmount = (taxableValue * inv.cgstRate) / 100.0
        val sgstAmount = (taxableValue * inv.sgstRate) / 100.0
        val igstAmount = (taxableValue * inv.igstRate) / 100.0
        val totalTax = cgstAmount + sgstAmount + igstAmount
        val total = taxableValue + totalTax
        val finalTotal = total.roundToLong().toDouble()
        val roundedOff = finalTotal - total
        val words = IndianCurrencyWordConverter.convert(finalTotal)

        return FullInvoiceTotals(
            itemsTotal = itemsTotal,
            taxableValue = taxableValue,
            cgstAmount = cgstAmount,
            sgstAmount = sgstAmount,
            igstAmount = igstAmount,
            totalTax = totalTax,
            roundedOff = roundedOff,
            finalTotal = finalTotal,
            words = words
        )
    }

    fun saveFullInvoice(onSaved: (Long) -> Unit = {}) {
        viewModelScope.launch {
            val entity = _fullInvoice.value.copy(
                id = _currentInvoiceId.value ?: 0,
                itemsJson = FullInvoiceEntity.itemsToJson(_fullInvoiceItems.value),
                updatedAt = System.currentTimeMillis()
            )
            val newId = repository.saveFullInvoice(entity)
            _currentInvoiceId.value = newId
            onSaved(newId)
        }
    }

    fun loadFullInvoice(entity: FullInvoiceEntity) {
        _currentInvoiceId.value = entity.id
        _fullInvoice.value = entity
        _fullInvoiceItems.value = entity.getItems()
    }

    fun resetFullInvoice() {
        _currentInvoiceId.value = null
        _fullInvoice.value = FullInvoiceEntity(
            invoiceDate = IndianCurrencyWordConverter.getCurrentDateIso(),
            challanDate = IndianCurrencyWordConverter.getCurrentDateIso(),
            orderDate = IndianCurrencyWordConverter.getCurrentDateIso()
        )
        _fullInvoiceItems.value = listOf(InvoiceItem())
    }

    fun deleteFullInvoice(id: Long) {
        viewModelScope.launch {
            repository.deleteFullInvoice(id)
            if (_currentInvoiceId.value == id) {
                resetFullInvoice()
            }
        }
    }

    // SIMPLE ESTIMATE STATE
    private val _currentEstimateId = MutableStateFlow<Long?>(null)
    val currentEstimateId: StateFlow<Long?> = _currentEstimateId.asStateFlow()

    private val _simpleEstimate = MutableStateFlow(
        SimpleEstimateEntity(
            date = IndianCurrencyWordConverter.getCurrentDateIso()
        )
    )
    val simpleEstimate: StateFlow<SimpleEstimateEntity> = _simpleEstimate.asStateFlow()

    private val _estimateItems = MutableStateFlow(listOf(EstimateItem()))
    val estimateItems: StateFlow<List<EstimateItem>> = _estimateItems.asStateFlow()

    // SIMPLE ESTIMATE METHODS
    fun updateEstimateField(transform: (SimpleEstimateEntity) -> SimpleEstimateEntity) {
        _simpleEstimate.value = transform(_simpleEstimate.value)
    }

    fun addEstimateItem() {
        _estimateItems.value = _estimateItems.value + EstimateItem(id = System.currentTimeMillis())
    }

    fun removeEstimateItem(id: Long) {
        if (_estimateItems.value.size > 1) {
            _estimateItems.value = _estimateItems.value.filter { it.id != id }
        }
    }

    fun updateEstimateItem(id: Long, qty: String? = null, desc: String? = null, rate: String? = null) {
        _estimateItems.value = _estimateItems.value.map { item ->
            if (item.id == id) {
                val newQty = qty ?: item.quantity
                val newDesc = desc ?: item.description
                val newRate = rate ?: item.rate

                val q = newQty.toDoubleOrNull() ?: 0.0
                val r = newRate.toDoubleOrNull() ?: 0.0
                val newAmount = if (q > 0 && r > 0) q * r else 0.0

                item.copy(
                    quantity = newQty,
                    description = newDesc,
                    rate = newRate,
                    amount = newAmount
                )
            } else item
        }
    }

    fun toggleEstimateTag(itemId: Long, tag: String) {
        val tagSuffix = when (tag) {
            "drill" -> " (Drill)"
            "pipe" -> " (Pipe)"
            "oval" -> " (Oval)"
            "bl" -> " (BL)"
            else -> ""
        }
        if (tagSuffix.isEmpty()) return

        _estimateItems.value = _estimateItems.value.map { item ->
            if (item.id == itemId) {
                val newDrill = if (tag == "drill") !item.drill else item.drill
                val newPipe = if (tag == "pipe") !item.pipe else item.pipe
                val newOval = if (tag == "oval") !item.oval else item.oval
                val newBl = if (tag == "bl") !item.bl else item.bl

                val isCheckedNow = when (tag) {
                    "drill" -> newDrill
                    "pipe" -> newPipe
                    "oval" -> newOval
                    "bl" -> newBl
                    else -> false
                }

                val newDesc = if (isCheckedNow) {
                    if (!item.description.contains(tagSuffix)) {
                        item.description + tagSuffix
                    } else item.description
                } else {
                    item.description.replace(tagSuffix, "")
                }

                item.copy(
                    description = newDesc,
                    drill = newDrill,
                    pipe = newPipe,
                    oval = newOval,
                    bl = newBl
                )
            } else item
        }
    }

    fun getEstimateTotal(): Double {
        return _estimateItems.value.sumOf { it.amount }
    }

    fun saveSimpleEstimate(onSaved: (Long) -> Unit = {}) {
        viewModelScope.launch {
            val entity = _simpleEstimate.value.copy(
                id = _currentEstimateId.value ?: 0,
                itemsJson = SimpleEstimateEntity.itemsToJson(_estimateItems.value),
                updatedAt = System.currentTimeMillis()
            )
            val newId = repository.saveSimpleEstimate(entity)
            _currentEstimateId.value = newId
            onSaved(newId)
        }
    }

    fun loadSimpleEstimate(entity: SimpleEstimateEntity) {
        _currentEstimateId.value = entity.id
        _simpleEstimate.value = entity
        _estimateItems.value = entity.getItems()
    }

    fun resetSimpleEstimate() {
        _currentEstimateId.value = null
        _simpleEstimate.value = SimpleEstimateEntity(
            date = IndianCurrencyWordConverter.getCurrentDateIso()
        )
        _estimateItems.value = listOf(EstimateItem())
    }

    fun deleteSimpleEstimate(id: Long) {
        viewModelScope.launch {
            repository.deleteSimpleEstimate(id)
            if (_currentEstimateId.value == id) {
                resetSimpleEstimate()
            }
        }
    }
}
