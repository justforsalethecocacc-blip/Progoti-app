package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import org.json.JSONArray
import org.json.JSONObject

data class EstimateItem(
    val id: Long = System.currentTimeMillis(),
    val quantity: String = "",
    val description: String = "",
    val rate: String = "",
    val amount: Double = 0.0,
    val drill: Boolean = false,
    val pipe: Boolean = false,
    val oval: Boolean = false,
    val bl: Boolean = false
) {
    fun calculateAmount(): Double {
        val qty = quantity.toDoubleOrNull() ?: 0.0
        val r = rate.toDoubleOrNull() ?: 0.0
        return if (qty > 0 && r > 0) qty * r else 0.0
    }
}

@Entity(tableName = "simple_estimates")
data class SimpleEstimateEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val companyName: String = "YOUR COMPANY NAME",
    val customerName: String = "",
    val date: String = "",
    val itemsJson: String = "[]",
    val updatedAt: Long = System.currentTimeMillis()
) {
    fun getItems(): List<EstimateItem> {
        val list = mutableListOf<EstimateItem>()
        try {
            val arr = JSONArray(itemsJson)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    EstimateItem(
                        id = obj.optLong("id", System.currentTimeMillis() + i),
                        quantity = obj.optString("quantity", ""),
                        description = obj.optString("description", ""),
                        rate = obj.optString("rate", ""),
                        amount = obj.optDouble("amount", 0.0),
                        drill = obj.optBoolean("drill", false),
                        pipe = obj.optBoolean("pipe", false),
                        oval = obj.optBoolean("oval", false),
                        bl = obj.optBoolean("bl", false)
                    )
                )
            }
        } catch (_: Exception) {
        }
        if (list.isEmpty()) {
            list.add(EstimateItem())
        }
        return list
    }

    companion object {
        fun itemsToJson(items: List<EstimateItem>): String {
            val arr = JSONArray()
            for (item in items) {
                val obj = JSONObject()
                obj.put("id", item.id)
                obj.put("quantity", item.quantity)
                obj.put("description", item.description)
                obj.put("rate", item.rate)
                obj.put("amount", item.amount)
                obj.put("drill", item.drill)
                obj.put("pipe", item.pipe)
                obj.put("oval", item.oval)
                obj.put("bl", item.bl)
                arr.put(obj)
            }
            return arr.toString()
        }
    }
}
