package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.chooser.DocumentChooserScreen
import com.example.ui.fullinvoice.FullInvoiceScreen
import com.example.ui.history.SavedDocumentsDialog
import com.example.ui.simpleestimate.SimpleEstimateScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.InvoiceViewModel

enum class AppScreen {
    CHOOSER,
    FULL_INVOICE,
    SIMPLE_ESTIMATE
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainApp()
            }
        }
    }
}

@Composable
fun MainApp(invoiceViewModel: InvoiceViewModel = viewModel()) {
    var currentScreen by remember { mutableStateOf(AppScreen.CHOOSER) }
    var showSavedDocsSheet by remember { mutableStateOf(false) }

    val fullInvoices by invoiceViewModel.savedFullInvoices.collectAsState()
    val simpleEstimates by invoiceViewModel.savedSimpleEstimates.collectAsState()
    val totalSaved = fullInvoices.size + simpleEstimates.size

    Crossfade(
        targetState = currentScreen,
        modifier = Modifier.fillMaxSize(),
        label = "ScreenTransition"
    ) { screen ->
        when (screen) {
            AppScreen.CHOOSER -> {
                DocumentChooserScreen(
                    onSelectFullInvoice = {
                        currentScreen = AppScreen.FULL_INVOICE
                    },
                    onSelectSimpleEstimate = {
                        currentScreen = AppScreen.SIMPLE_ESTIMATE
                    },
                    onOpenSavedDocuments = {
                        showSavedDocsSheet = true
                    },
                    savedCount = totalSaved
                )
            }
            AppScreen.FULL_INVOICE -> {
                FullInvoiceScreen(
                    viewModel = invoiceViewModel,
                    onNavigateBack = {
                        currentScreen = AppScreen.CHOOSER
                    }
                )
            }
            AppScreen.SIMPLE_ESTIMATE -> {
                SimpleEstimateScreen(
                    viewModel = invoiceViewModel,
                    onNavigateBack = {
                        currentScreen = AppScreen.CHOOSER
                    }
                )
            }
        }
    }

    if (showSavedDocsSheet) {
        SavedDocumentsDialog(
            fullInvoices = fullInvoices,
            simpleEstimates = simpleEstimates,
            onSelectFullInvoice = { invoice ->
                invoiceViewModel.loadFullInvoice(invoice)
                currentScreen = AppScreen.FULL_INVOICE
            },
            onDeleteFullInvoice = { id ->
                invoiceViewModel.deleteFullInvoice(id)
            },
            onSelectSimpleEstimate = { estimate ->
                invoiceViewModel.loadSimpleEstimate(estimate)
                currentScreen = AppScreen.SIMPLE_ESTIMATE
            },
            onDeleteSimpleEstimate = { id ->
                invoiceViewModel.deleteSimpleEstimate(id)
            },
            onDismiss = {
                showSavedDocsSheet = false
            }
        )
    }
}

