package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.R
import com.example.data.model.FullInvoiceEntity
import com.example.data.model.SimpleEstimateEntity
import java.io.File
import java.io.FileOutputStream
import java.io.FileInputStream
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

object InvoicePdfGenerator {

    private const val PAGE_WIDTH = 595 // A4 standard pt
    private const val PAGE_HEIGHT = 842

    fun printFullInvoice(context: Context, invoice: FullInvoiceEntity) {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager
        if (printManager == null) {
            Toast.makeText(context, "Printing not supported on this device", Toast.LENGTH_SHORT).show()
            return
        }

        val safeCustomer = if (invoice.customerName.isNotBlank()) {
            invoice.customerName.replace(Regex("[^a-zA-Z0-9]"), "_").lowercase(Locale.ROOT)
        } else "customer"
        val jobName = "${safeCustomer}_inv_${invoice.invoiceNo.ifBlank { "NA" }}_ch_${invoice.challanNo.ifBlank { "NA" }}"

        val adapter = object : PrintDocumentAdapter() {
            private var pdfDoc: PdfDocument? = null

            override fun onLayout(
                oldAttributes: PrintAttributes?,
                newAttributes: PrintAttributes,
                cancellationSignal: CancellationSignal?,
                callback: LayoutResultCallback?,
                extras: Bundle?
            ) {
                if (cancellationSignal?.isCanceled == true) {
                    callback?.onLayoutCancelled()
                    return
                }

                val info = PrintDocumentInfo.Builder(jobName)
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .setPageCount(2) // Page 1: Tax Invoice, Page 2: Delivery Challan
                    .build()

                callback?.onLayoutFinished(info, true)
            }

            override fun onWrite(
                pages: Array<out PageRange>?,
                destination: ParcelFileDescriptor?,
                cancellationSignal: CancellationSignal?,
                callback: WriteResultCallback?
            ) {
                if (destination == null) {
                    callback?.onWriteFailed("No destination file")
                    return
                }

                pdfDoc = PdfDocument()
                try {
                    // Page 1: Tax Invoice
                    val pageInfo1 = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 1).create()
                    val page1 = pdfDoc!!.startPage(pageInfo1)
                    drawTaxInvoicePage(context, page1.canvas, invoice)
                    pdfDoc!!.finishPage(page1)

                    // Page 2: Delivery Challan
                    val pageInfo2 = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 2).create()
                    val page2 = pdfDoc!!.startPage(pageInfo2)
                    drawDeliveryChallanPage(context, page2.canvas, invoice)
                    pdfDoc!!.finishPage(page2)

                    FileOutputStream(destination.fileDescriptor).use { out ->
                        pdfDoc!!.writeTo(out)
                    }

                    callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                } catch (e: Exception) {
                    callback?.onWriteFailed(e.message)
                } finally {
                    pdfDoc?.close()
                    pdfDoc = null
                }
            }
        }

        val printAttributes = PrintAttributes.Builder()
            .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
            .build()
        printManager.print(jobName, adapter, printAttributes)
    }

    fun shareFullInvoicePdf(context: Context, invoice: FullInvoiceEntity) {
        try {
            val safeCustomer = if (invoice.customerName.isNotBlank()) {
                invoice.customerName.replace(Regex("[^a-zA-Z0-9]"), "_").lowercase(Locale.ROOT)
            } else "customer"
            val safeInv = invoice.invoiceNo.replace(Regex("[^a-zA-Z0-9]"), "_").ifBlank { "NA" }
            val safeCh = invoice.challanNo.replace(Regex("[^a-zA-Z0-9]"), "_").ifBlank { "NA" }
            val fileName = "${safeCustomer}_inv_${safeInv}_ch_${safeCh}.pdf"
            val file = File(context.cacheDir, fileName)

            val pdfDoc = PdfDocument()
            val pageInfo1 = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 1).create()
            val page1 = pdfDoc.startPage(pageInfo1)
            drawTaxInvoicePage(context, page1.canvas, invoice)
            pdfDoc.finishPage(page1)

            val pageInfo2 = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 2).create()
            val page2 = pdfDoc.startPage(pageInfo2)
            drawDeliveryChallanPage(context, page2.canvas, invoice)
            pdfDoc.finishPage(page2)

            FileOutputStream(file).use { out ->
                pdfDoc.writeTo(out)
            }
            pdfDoc.close()

            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "Invoice ${invoice.invoiceNo} - Progoti Engineering Works")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Share Invoice PDF"))
        } catch (e: Exception) {
            Toast.makeText(context, "Error creating PDF: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    fun printSimpleEstimate(context: Context, estimate: SimpleEstimateEntity) {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager
        if (printManager == null) {
            Toast.makeText(context, "Printing not supported on this device", Toast.LENGTH_SHORT).show()
            return
        }

        val items = estimate.getItems()
        val pagesCount = max(1, (items.size + 11) / 12)
        val customerPart = if (estimate.customerName.isNotBlank()) {
            estimate.customerName.trim().replace(Regex("\\s+"), "_")
        } else "customer"
        val datePart = if (estimate.date.isNotBlank()) {
            IndianCurrencyWordConverter.formatDateToDDMMYYYY(estimate.date).replace("/", "-")
        } else "no-date"
        val jobName = "Estimate-$customerPart-$datePart"

        val adapter = object : PrintDocumentAdapter() {
            private var pdfDoc: PdfDocument? = null

            override fun onLayout(
                oldAttributes: PrintAttributes?,
                newAttributes: PrintAttributes,
                cancellationSignal: CancellationSignal?,
                callback: LayoutResultCallback?,
                extras: Bundle?
            ) {
                if (cancellationSignal?.isCanceled == true) {
                    callback?.onLayoutCancelled()
                    return
                }

                val info = PrintDocumentInfo.Builder(jobName)
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .setPageCount(pagesCount)
                    .build()

                callback?.onLayoutFinished(info, true)
            }

            override fun onWrite(
                pages: Array<out PageRange>?,
                destination: ParcelFileDescriptor?,
                cancellationSignal: CancellationSignal?,
                callback: WriteResultCallback?
            ) {
                if (destination == null) {
                    callback?.onWriteFailed("No destination file")
                    return
                }

                pdfDoc = PdfDocument()
                try {
                    for (i in 0 until pagesCount) {
                        val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, i + 1).create()
                        val page = pdfDoc!!.startPage(pageInfo)
                        drawSimpleEstimatePage(page.canvas, estimate, i, pagesCount)
                        pdfDoc!!.finishPage(page)
                    }

                    FileOutputStream(destination.fileDescriptor).use { out ->
                        pdfDoc!!.writeTo(out)
                    }

                    callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                } catch (e: Exception) {
                    callback?.onWriteFailed(e.message)
                } finally {
                    pdfDoc?.close()
                    pdfDoc = null
                }
            }
        }

        val printAttributes = PrintAttributes.Builder()
            .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
            .build()
        printManager.print(jobName, adapter, printAttributes)
    }

    fun shareSimpleEstimatePdf(context: Context, estimate: SimpleEstimateEntity) {
        try {
            val items = estimate.getItems()
            val pagesCount = max(1, (items.size + 11) / 12)
            val customerPart = if (estimate.customerName.isNotBlank()) {
                estimate.customerName.trim().replace(Regex("[^a-zA-Z0-9]"), "_")
            } else "customer"
            val datePart = if (estimate.date.isNotBlank()) {
                IndianCurrencyWordConverter.formatDateToDDMMYYYY(estimate.date).replace("/", "-")
            } else "no-date"
            val fileName = "Estimate-$customerPart-$datePart.pdf"
            val file = File(context.cacheDir, fileName)

            val pdfDoc = PdfDocument()
            for (i in 0 until pagesCount) {
                val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, i + 1).create()
                val page = pdfDoc.startPage(pageInfo)
                drawSimpleEstimatePage(page.canvas, estimate, i, pagesCount)
                pdfDoc.finishPage(page)
            }

            FileOutputStream(file).use { out ->
                pdfDoc.writeTo(out)
            }
            pdfDoc.close()

            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "Estimate - ${estimate.customerName}")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Share Estimate PDF"))
        } catch (e: Exception) {
            Toast.makeText(context, "Error creating PDF: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun formatDisplayQuantity(quantity: String): String {
        val trimmed = quantity.trim()
        if (trimmed.isBlank()) return ""
        val lower = trimmed.lowercase(Locale.ROOT)
        if (lower.endsWith("nos") || lower.endsWith("no") || lower.endsWith("no.") ||
            lower.endsWith("pcs") || lower.endsWith("pc") || lower.endsWith("set") ||
            lower.endsWith("sets") || lower.endsWith("kg") || lower.endsWith("mtr") ||
            lower.endsWith("ft") || lower.endsWith("feet")) {
            return trimmed
        }
        return "$trimmed Nos."
    }

    // DRAWING TAX INVOICE (Page 1)
    fun drawTaxInvoicePage(context: Context, canvas: Canvas, invoice: FullInvoiceEntity) {
        // Background white
        canvas.drawColor(Color.WHITE)

        val strokePaint = Paint().apply {
            color = Color.parseColor("#1e3a8a") // blue-900
            style = Paint.Style.STROKE
            strokeWidth = 2.5f
        }
        val thinStrokePaint = Paint().apply {
            color = Color.parseColor("#1f2937") // gray-800
            style = Paint.Style.STROKE
            strokeWidth = 0.8f
        }
        val fillHeaderPaint = Paint().apply {
            color = Color.parseColor("#f3f4f6") // gray-100
            style = Paint.Style.FILL
        }
        val textPaint = Paint().apply {
            color = Color.BLACK
            textSize = 9f
            isAntiAlias = true
            isLinearText = true
            isSubpixelText = true
        }
        val boldPaint = Paint().apply {
            color = Color.BLACK
            textSize = 9f
            typeface = Typeface.DEFAULT_BOLD
            isAntiAlias = true
            isLinearText = true
            isSubpixelText = true
        }
        val blueTitlePaint = Paint().apply {
            color = Color.parseColor("#1e3a8a")
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            isAntiAlias = true
            isLinearText = true
            isSubpixelText = true
        }

        val margin = 22f
        val left = margin
        val top = margin
        val right = PAGE_WIDTH - margin
        val bottom = PAGE_HEIGHT - margin

        // Outer Border
        canvas.drawRect(left, top, right, bottom, strokePaint)

        // HEADER (Top)
        val headerBottom = top + 72f
        canvas.drawLine(left, headerBottom, right, headerBottom, strokePaint)

        // Try load logo
        try {
            val options = BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.ARGB_8888 }
            val logo = BitmapFactory.decodeResource(context.resources, R.drawable.progoti_header, options)
            if (logo != null) {
                val destRect = Rect(left.toInt() + 6, top.toInt() + 10, left.toInt() + 54, top.toInt() + 58)
                canvas.drawBitmap(logo, null, destRect, null)
            }
        } catch (_: Exception) {}

        // Company Details text
        val textLeft = left + 60f
        canvas.drawText("PROGOTI ENGINEERING WORKS", textLeft, top + 16f, blueTitlePaint)

        val redSubPaint = Paint().apply {
            color = Color.parseColor("#dc2626")
            textSize = 7.5f
            typeface = Typeface.DEFAULT_BOLD
            isAntiAlias = true
            isLinearText = true
            isSubpixelText = true
        }
        val blueSubPaint = Paint().apply {
            color = Color.parseColor("#1e40af")
            textSize = 7.5f
            typeface = Typeface.DEFAULT_BOLD
            isAntiAlias = true
            isLinearText = true
            isSubpixelText = true
        }
        canvas.drawText("Manufacturers of All Kind and General Order Suppliers", textLeft, top + 28f, redSubPaint)
        canvas.drawText("Specialist in I.S., B.S. & A.S.T.M. QUALITY SOCKETS", textLeft, top + 39f, blueSubPaint)
        canvas.drawText("And All types of Machinery Labour Jobs.", textLeft, top + 50f, blueSubPaint)
        canvas.drawText("Office & Works: 119, I. R. Belilious Lane, Howrah-711101, W.B. India", textLeft, top + 61f, blueSubPaint)

        // Right side badge: "TAX INVOICE" + Copies checkboxes
        val badgeWidth = 130f
        val badgeLeft = right - badgeWidth - 6f
        val badgePaint = Paint().apply {
            color = Color.parseColor("#dc2626")
            style = Paint.Style.FILL
        }
        canvas.drawRect(badgeLeft, top + 4f, right - 6f, top + 20f, badgePaint)
        val whiteBadgeText = Paint().apply {
            color = Color.WHITE
            textSize = 9.5f
            typeface = Typeface.DEFAULT_BOLD
            isAntiAlias = true
            isLinearText = true
            isSubpixelText = true
        }
        canvas.drawText("TAX INVOICE", badgeLeft + 26f, top + 16f, whiteBadgeText)

        // Copy checkboxes
        val copyTextPaint = Paint().apply {
            color = Color.BLACK
            textSize = 6.5f
            isAntiAlias = true
            isLinearText = true
            isSubpixelText = true
        }
        var copyY = top + 29f
        fun drawCopyCheck(label: String, checked: Boolean) {
            canvas.drawRect(badgeLeft + 6f, copyY - 6.5f, badgeLeft + 13.5f, copyY + 1f, thinStrokePaint)
            if (checked) {
                canvas.drawLine(badgeLeft + 6f, copyY - 6.5f, badgeLeft + 13.5f, copyY + 1f, thinStrokePaint)
                canvas.drawLine(badgeLeft + 13.5f, copyY - 6.5f, badgeLeft + 6f, copyY + 1f, thinStrokePaint)
            }
            canvas.drawText(label, badgeLeft + 18f, copyY, copyTextPaint)
            copyY += 10.5f
        }
        drawCopyCheck("ORIGINAL BUYER'S COPY", invoice.copyOriginal)
        drawCopyCheck("DUPLICATE BUYER'S COPY", invoice.copyDuplicate)
        drawCopyCheck("SELLER'S COPY", invoice.copySeller)
        drawCopyCheck("TRANSPORTER'S COPY", invoice.copyTransporter)

        // SECTION: Receiver Details (Left) vs Invoice Details (Right)
        val midX = left + (right - left) * 0.4f // Shifted 10% left
        val metaBottom = headerBottom + 150f
        canvas.drawLine(midX, headerBottom, midX, metaBottom, strokePaint)
        canvas.drawLine(left, metaBottom, right, metaBottom, strokePaint)

        // Header Strips (Height 20f, perfectly vertically centered)
        val headerStripH = 20f
        canvas.drawRect(left + 1f, headerBottom + 1f, midX - 1f, headerBottom + headerStripH, fillHeaderPaint)
        canvas.drawRect(midX + 1f, headerBottom + 1f, right - 1f, headerBottom + headerStripH, fillHeaderPaint)
        canvas.drawLine(left, headerBottom + headerStripH, right, headerBottom + headerStripH, strokePaint)

        val sectionTitlePaint = Paint().apply {
            color = Color.parseColor("#1e3a8a")
            textSize = 9.5f
            typeface = Typeface.DEFAULT_BOLD
            isAntiAlias = true
            isLinearText = true
            isSubpixelText = true
        }
        val headerTextY = headerBottom + 14f
        canvas.drawText("Details of Receiver (Billed to)", left + 8f, headerTextY, sectionTitlePaint)
        
        val metaBoldPaint = Paint().apply {
            color = Color.BLACK
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            isAntiAlias = true
            isLinearText = true
            isSubpixelText = true
        }
        val metaTextPaint = Paint().apply {
            color = Color.BLACK
            textSize = 10f
            isAntiAlias = true
            isLinearText = true
            isSubpixelText = true
        }
        
        val rightHeaderBoldPaint = Paint(metaBoldPaint).apply { textSize = 9.5f }
        val rightHeaderTextPaint = Paint(metaTextPaint).apply { textSize = 9.5f }

        // Add GSTIN to the Right Header Strip (same Y as "Details of Receiver")
        // Segments are measured and laid out sequentially (instead of hard-coded x
        // offsets) so the line can never overlap itself or spill past the strip,
        // no matter how wide the actual glyphs render on a given device/font.
        data class HeaderSeg(val text: String, val paint: Paint)
        val gstinSegments = listOf(
            HeaderSeg("GSTIN: ", rightHeaderBoldPaint),
            HeaderSeg("19AAEFP0503D1ZS", rightHeaderBoldPaint),
            HeaderSeg("   State: ", rightHeaderBoldPaint),
            HeaderSeg("West Bengal | ", rightHeaderTextPaint),
            HeaderSeg("Code: ", rightHeaderBoldPaint),
            HeaderSeg("19", rightHeaderTextPaint)
        )
        val gstinAvailableW = (right - 1f) - (midX + 8f)
        val gstinTotalW = gstinSegments.sumOf { it.paint.measureText(it.text).toDouble() }.toFloat()
        // If the line would still overflow the strip, shrink all its paints together
        // (proportionally) until it fits, instead of letting it run past the border.
        val gstinScale = if (gstinTotalW > gstinAvailableW) (gstinAvailableW / gstinTotalW).coerceAtLeast(0.75f) else 1f
        val scaledBold = Paint(rightHeaderBoldPaint).apply { textSize = rightHeaderBoldPaint.textSize * gstinScale }
        val scaledText = Paint(rightHeaderTextPaint).apply { textSize = rightHeaderTextPaint.textSize * gstinScale }
        var gstinX = midX + 8f
        for (seg in gstinSegments) {
            val paint = if (seg.paint === rightHeaderBoldPaint) scaledBold else scaledText
            canvas.drawText(seg.text, gstinX, headerTextY, paint)
            gstinX += paint.measureText(seg.text)
        }
        
        var lY = headerBottom + headerStripH + 13f
        
        fun drawReceiverField(label: String, value: String) {
            canvas.drawText(label, left + 8f, lY, metaBoldPaint)
            lY += 13f
            if (value.isNotBlank()) {
                canvas.drawText(value.take(45), left + 10f, lY, metaTextPaint)
                lY += 15f
            } else {
                lY += 2f
            }
        }
        
        drawReceiverField("Name:", invoice.customerName)
        
        canvas.drawText("Address:", left + 8f, lY, metaBoldPaint)
        lY += 13f
        if (invoice.customerAddress.isNotBlank()) {
            canvas.drawText(invoice.customerAddress.take(45), left + 10f, lY, metaTextPaint)
            lY += 13f
            if (invoice.customerAddress.length > 45) {
                canvas.drawText(invoice.customerAddress.substring(45).take(45), left + 10f, lY, metaTextPaint)
                lY += 15f
            } else {
                lY += 2f
            }
        } else {
            lY += 2f
        }
        
        drawReceiverField("GSTIN:", invoice.customerGSTIN)

        // State & State Code pushed down together on their own lines right above the bottom divider
        val stateLabelY = metaBottom - 20f
        val stateValueY = metaBottom - 6f
        
        val sLabel = "State:"
        canvas.drawText(sLabel, left + 8f, stateLabelY, metaBoldPaint)
        val sVal = invoice.customerState.ifBlank { "West Bengal" }
        canvas.drawText(sVal, left + 10f, stateValueY, metaTextPaint)

        val cLabel = "State Code:"
        val cVal = invoice.customerStateCode.ifBlank { "19" }
        val cX = midX - 95f
        canvas.drawText(cLabel, cX, stateLabelY, metaBoldPaint)
        canvas.drawText(cVal, cX + 22f, stateValueY, metaTextPaint)

        var rY = headerBottom + headerStripH + 13f
        
        fun drawSingleMeta(label: String, value: String) {
            canvas.drawText(label, midX + 8f, rY, metaBoldPaint)
            if (value.isNotBlank()) {
                canvas.drawText(value, midX + 110f, rY, metaTextPaint)
            }
            rY += 16f
        }
        drawSingleMeta("Invoice No.:", invoice.invoiceNo)
        drawSingleMeta("Date:", IndianCurrencyWordConverter.formatDateToDDMMYYYY(invoice.invoiceDate))
        drawSingleMeta("Challan No.:", invoice.challanNo)
        drawSingleMeta("Date:", IndianCurrencyWordConverter.formatDateToDDMMYYYY(invoice.challanDate))
        drawSingleMeta("Order No.:", invoice.orderNo)
        drawSingleMeta("Date:", IndianCurrencyWordConverter.formatDateToDDMMYYYY(invoice.orderDate))
        drawSingleMeta("Transportation:", invoice.transportationMode)
        drawSingleMeta("Vehicle Number:", invoice.vehicleNumber)

        // TABLE SECTION (Cols: Qty (75), Description (flex), HSN (70), Rate (80), Amount (100))
        val tableTop = metaBottom
        val tableHeaderHeight = 20f
        canvas.drawRect(left, tableTop, right, tableTop + tableHeaderHeight, fillHeaderPaint)
        canvas.drawLine(left, tableTop + tableHeaderHeight, right, tableTop + tableHeaderHeight, strokePaint)

        val colQty = left + 75f
        val colHsn = right - 250f
        val colRate = right - 180f
        val colAmount = right - 100f

        fun drawTableVLines(y1: Float, y2: Float) {
            canvas.drawLine(colQty, y1, colQty, y2, thinStrokePaint)
            canvas.drawLine(colHsn, y1, colHsn, y2, thinStrokePaint)
            canvas.drawLine(colRate, y1, colRate, y2, thinStrokePaint)
            canvas.drawLine(colAmount, y1, colAmount, y2, thinStrokePaint)
        }
        drawTableVLines(tableTop, tableTop + tableHeaderHeight)

        fun drawCenteredText(text: String, startX: Float, endX: Float, y: Float, paint: Paint) {
            var p = paint
            var w = p.measureText(text)
            val maxW = endX - startX - 4f
            if (w > maxW && maxW > 0) {
                p = Paint(paint)
                p.textSize = paint.textSize * (maxW / w)
                w = p.measureText(text)
            }
            canvas.drawText(text, startX + (endX - startX) / 2f - w / 2f, y, p)
        }
        
        fun drawRightText(text: String, endX: Float, y: Float, paint: Paint, maxW: Float) {
            var p = paint
            var w = p.measureText(text)
            if (w > maxW && maxW > 0) {
                p = Paint(paint)
                p.textSize = paint.textSize * (maxW / w)
                w = p.measureText(text)
            }
            canvas.drawText(text, endX - w - 4f, y, p)
        }

        drawCenteredText("Qty", left, colQty, tableTop + 14f, boldPaint)
        drawCenteredText("DESCRIPTION OF GOODS", colQty, colHsn, tableTop + 14f, boldPaint)
        drawCenteredText("HSN", colHsn, colRate, tableTop + 14f, boldPaint)
        drawCenteredText("Rate (Rs.)", colRate, colAmount, tableTop + 14f, boldPaint)
        drawCenteredText("AMOUNT (Rs.)", colAmount, right, tableTop + 14f, boldPaint)

        // FOOTER is fixed at bottom - 188f to perfectly fit all rows and leave no gaps
        val footerTop = bottom - 188f
        val tableContentHeight = footerTop - (tableTop + tableHeaderHeight)
        val items = invoice.getItems()
        val displayItemRows = maxOf(10, minOf(15, items.size))
        val totalTableRows = displayItemRows + 1 // Row 0 (Labour charges) + displayItemRows
        val rowHeight = tableContentHeight / totalTableRows

        val dynamicRowTextSize = if (totalTableRows <= 11) 11.5f else if (totalTableRows <= 13) 10.5f else 9.5f
        textPaint.textSize = dynamicRowTextSize
        boldPaint.textSize = dynamicRowTextSize

        var curY = tableTop + tableHeaderHeight

        // Row 0: Labour Charges fixed row
        val lQty = "Nos"
        val lDesc = invoice.labourChargesDescription
        val lRate = "Each"
        val lAmt = if (invoice.labourCharges > 0) String.format(Locale.US, "%.2f", invoice.labourCharges) else ""

        val italicPaint = Paint().apply {
            color = Color.BLACK
            textSize = dynamicRowTextSize
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.ITALIC)
            isAntiAlias = true
            isLinearText = true
            isSubpixelText = true
        }

        fun drawLeftScaledText(text: String, startX: Float, y: Float, paint: Paint, maxW: Float) {
            var p = paint
            var w = p.measureText(text)
            if (w > maxW && maxW > 0) {
                p = Paint(paint)
                p.textSize = paint.textSize * (maxW / w)
            }
            canvas.drawText(text, startX, y, p)
        }

        canvas.drawLine(left, curY + rowHeight, right, curY + rowHeight, thinStrokePaint)
        drawTableVLines(curY, curY + rowHeight)
        drawCenteredText(lQty, left, colQty, curY + rowHeight - 6f, italicPaint)
        drawLeftScaledText(lDesc, colQty + 6f, curY + rowHeight - 6f, textPaint, colHsn - colQty - 12f)
        drawCenteredText(lRate, colHsn, colRate, curY + rowHeight - 6f, italicPaint)
        if (lAmt.isNotBlank()) {
            drawRightText(lAmt, right, curY + rowHeight - 6f, textPaint, right - colAmount)
        }
        curY += rowHeight

        // Item rows + blank grid rows all the way to footerTop
        for (i in 0 until (totalTableRows - 1)) {
            val nextY = if (i == totalTableRows - 2) footerTop else curY + rowHeight
            canvas.drawLine(left, nextY, right, nextY, thinStrokePaint)
            drawTableVLines(curY, nextY)

            if (i < items.size) {
                val item = items[i]
                if (item.quantity.isNotBlank() || item.description.isNotBlank() || item.rate.isNotBlank()) {
                    drawCenteredText(formatDisplayQuantity(item.quantity), left, colQty, curY + rowHeight - 6f, textPaint)
                    drawLeftScaledText(item.description, colQty + 6f, curY + rowHeight - 6f, textPaint, colHsn - colQty - 12f)
                    drawCenteredText(item.hsnCode, colHsn, colRate, curY + rowHeight - 6f, textPaint)
                    if (item.rate.isNotBlank()) {
                        drawCenteredText(item.rate, colRate, colAmount, curY + rowHeight - 6f, textPaint)
                    }
                    if (item.amount > 0) {
                        val aStr = String.format(Locale.US, "%.2f", item.amount)
                        drawRightText(aStr, right, curY + rowHeight - 6f, boldPaint, right - colAmount)
                    }
                }
            }
            curY = nextY
        }

        // FOOTER / TOTALS SECTION
        canvas.drawLine(left, footerTop, right, footerTop, strokePaint)
        canvas.drawLine(midX, footerTop, midX, bottom, strokePaint)

        // Calculations
        val itemsTotal = items.sumOf { it.amount }
        val taxableValue = itemsTotal + invoice.labourCharges
        val cgstAmount = (taxableValue * invoice.cgstRate) / 100.0
        val sgstAmount = (taxableValue * invoice.sgstRate) / 100.0
        val igstAmount = (taxableValue * invoice.igstRate) / 100.0
        val totalTax = cgstAmount + sgstAmount + igstAmount
        val total = taxableValue + totalTax
        val finalTotal = Math.round(total).toDouble()
        val roundedOff = finalTotal - total

        // Left Footer: Payment info, words, vehicle, jurisdiction
        val redAlertPaint = Paint().apply {
            color = Color.parseColor("#dc2626")
            textSize = 8f
            typeface = Typeface.DEFAULT_BOLD
            isAntiAlias = true
            isLinearText = true
            isSubpixelText = true
        }
        canvas.drawText("Please pay by A/c. Payee Cheque Only", left + 6f, footerTop + 14f, redAlertPaint)

        canvas.drawText("Rupees in words:", left + 6f, footerTop + 27f, italicPaint)
        val words = IndianCurrencyWordConverter.convert(finalTotal)
        canvas.drawText(words.take(45), left + 6f, footerTop + 39f, boldPaint)
        if (words.length > 45) {
            canvas.drawText(words.substring(45).take(45), left + 6f, footerTop + 50f, boldPaint)
        }

        canvas.drawText("Interest @ 24% if Bill not paid on presentation", left + 6f, footerTop + 65f, italicPaint)

        canvas.drawText("Vehicle:", left + 6f, footerTop + 80f, boldPaint)
        if (invoice.vehicleNumber.isNotBlank()) {
            canvas.drawText(invoice.vehicleNumber, left + 50f, footerTop + 80f, textPaint)
        }

        canvas.drawText("SUBJECT TO HOWRAH JURISDICTION", left + 6f, bottom - 10f, boldPaint)

        // Right Footer: Taxable Value, CGST, SGST, IGST, Total Tax, Rounded off, TOTAL, Signatory
        // Row 1: Taxable Value
        val taxValStr = String.format(Locale.US, "%.2f", taxableValue)
        canvas.drawText("Taxable Value", midX + 6f, footerTop + 13f, textPaint)
        canvas.drawText(taxValStr, right - textPaint.measureText(taxValStr) - 6f, footerTop + 13f, textPaint)
        canvas.drawLine(midX, footerTop + 17f, right, footerTop + 17f, thinStrokePaint)

        // Row 2: CGST
        val cgstStr = String.format(Locale.US, "%.2f", cgstAmount)
        canvas.drawText("Add: CGST @", midX + 6f, footerTop + 29f, textPaint)
        canvas.drawText("${invoice.cgstRate.toInt()}", midX + 75f, footerTop + 29f, textPaint)
        canvas.drawText("%", midX + 94f, footerTop + 29f, textPaint)
        canvas.drawText(cgstStr, right - textPaint.measureText(cgstStr) - 6f, footerTop + 29f, textPaint)

        // Row 3: SGST
        val sgstStr = String.format(Locale.US, "%.2f", sgstAmount)
        canvas.drawText("Add: SGST @", midX + 6f, footerTop + 41f, textPaint)
        canvas.drawText("${invoice.sgstRate.toInt()}", midX + 75f, footerTop + 41f, textPaint)
        canvas.drawText("%", midX + 94f, footerTop + 41f, textPaint)
        canvas.drawText(sgstStr, right - textPaint.measureText(sgstStr) - 6f, footerTop + 41f, textPaint)

        // Row 4: IGST
        val igstStr = String.format(Locale.US, "%.2f", igstAmount)
        canvas.drawText("Add: IGST @", midX + 6f, footerTop + 53f, textPaint)
        canvas.drawText("${invoice.igstRate.toInt()}", midX + 75f, footerTop + 53f, textPaint)
        canvas.drawText("%", midX + 94f, footerTop + 53f, textPaint)
        canvas.drawText(igstStr, right - textPaint.measureText(igstStr) - 6f, footerTop + 53f, textPaint)
        canvas.drawLine(midX, footerTop + 57f, right, footerTop + 57f, thinStrokePaint)

        // Row 5: Total Tax Amount
        val totalTaxStr = String.format(Locale.US, "%.2f", totalTax)
        canvas.drawText("Total Tax Amount", midX + 6f, footerTop + 69f, textPaint)
        canvas.drawText(totalTaxStr, right - textPaint.measureText(totalTaxStr) - 6f, footerTop + 69f, textPaint)

        // Row 6: Rounded off (+/-)
        val roundPrefix = if (roundedOff > 0) "+" else ""
        val roundStr = roundPrefix + String.format(Locale.US, "%.2f", roundedOff)
        canvas.drawText("Rounded off (+/-)", midX + 6f, footerTop + 81f, textPaint)
        canvas.drawText(roundStr, right - textPaint.measureText(roundStr) - 6f, footerTop + 81f, textPaint)
        canvas.drawLine(midX, footerTop + 85f, right, footerTop + 85f, strokePaint)

        // Row 7: TOTAL
        val totalStr = String.format(Locale.US, "%.2f", finalTotal)
        canvas.drawText("TOTAL", midX + 6f, footerTop + 99f, boldPaint)
        canvas.drawText(totalStr, right - boldPaint.measureText(totalStr) - 6f, footerTop + 99f, boldPaint)
        canvas.drawLine(midX, footerTop + 104f, right, footerTop + 104f, thinStrokePaint)

        // Signatory block
        val smallItalic = Paint().apply {
            color = Color.BLACK
            textSize = 7f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.ITALIC)
            isAntiAlias = true
            isLinearText = true
            isSubpixelText = true
        }
        val eoeStr = "E. & O. E."
        canvas.drawText(eoeStr, right - smallItalic.measureText(eoeStr) - 6f, footerTop + 116f, smallItalic)

        val forStr = "For PROGOTI ENGINEERING WORKS"
        canvas.drawText(forStr, right - boldPaint.measureText(forStr) - 6f, footerTop + 128f, boldPaint)

        val authStr = "Authorised Signatory"
        canvas.drawText(authStr, right - smallItalic.measureText(authStr) - 6f, bottom - 10f, smallItalic)

        // Final outer border pass to guarantee uniform stroke and sharp edges
        canvas.drawRect(left, top, right, bottom, strokePaint)
    }

    // DRAWING DELIVERY CHALLAN (Page 2)
    fun drawDeliveryChallanPage(context: Context, canvas: Canvas, invoice: FullInvoiceEntity) {
        canvas.drawColor(Color.WHITE)

        val strokePaint = Paint().apply {
            color = Color.BLACK
            style = Paint.Style.STROKE
            strokeWidth = 2f
        }
        val thinStrokePaint = Paint().apply {
            color = Color.BLACK
            style = Paint.Style.STROKE
            strokeWidth = 0.8f
        }
        val textPaint = Paint().apply {
            color = Color.BLACK
            textSize = 9.5f
            isAntiAlias = true
            isLinearText = true
            isSubpixelText = true
        }
        val boldPaint = Paint().apply {
            color = Color.BLACK
            textSize = 9.5f
            typeface = Typeface.DEFAULT_BOLD
            isAntiAlias = true
            isLinearText = true
            isSubpixelText = true
        }
        val titlePaint = Paint().apply {
            color = Color.BLACK
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            isAntiAlias = true
            isLinearText = true
            isSubpixelText = true
        }

        val margin = 22f
        val left = margin
        val top = margin
        val right = PAGE_WIDTH - margin
        val bottom = PAGE_HEIGHT - margin

        // Border
        canvas.drawRect(left, top, right, bottom, strokePaint)

        var y = top + 24f
        // Challan No & Date
        canvas.drawText("Challan No.", left + 10f, y, boldPaint)
        canvas.drawText(invoice.challanNo, left + 75f, y, boldPaint)
        canvas.drawLine(left + 70f, y + 2f, left + 220f, y + 2f, strokePaint)

        canvas.drawText("Date", right - 130f, y, boldPaint)
        canvas.drawText(IndianCurrencyWordConverter.formatDateToDDMMYYYY(invoice.challanDate), right - 95f, y, boldPaint)
        canvas.drawLine(right - 100f, y + 2f, right - 10f, y + 2f, strokePaint)
        y += 24f

        // Messrs & Address
        canvas.drawText("Messrs", left + 10f, y, boldPaint)
        canvas.drawText(invoice.customerName, left + 55f, y, textPaint)
        canvas.drawLine(left + 50f, y + 2f, right - 10f, y + 2f, strokePaint)
        y += 22f

        canvas.drawText("Address", left + 10f, y, boldPaint)
        canvas.drawText(invoice.customerAddress, left + 55f, y, textPaint)
        canvas.drawLine(left + 50f, y + 2f, right - 10f, y + 2f, strokePaint)
        y += 34f

        // Company Header Center
        val cTitle = "PROGOTI ENGINEERING WORKS"
        canvas.drawText(cTitle, (PAGE_WIDTH - titlePaint.measureText(cTitle)) / 2f, y, titlePaint)
        y += 14f

        val subPaint = Paint().apply {
            color = Color.BLACK
            textSize = 8f
            typeface = Typeface.DEFAULT_BOLD
            isAntiAlias = true
            isLinearText = true
            isSubpixelText = true
        }
        val s1 = "Manufacturers of ALL KINDS OF PIPE FITTINGS AND GENERAL ORDER SUPPLIERS"
        canvas.drawText(s1, (PAGE_WIDTH - subPaint.measureText(s1)) / 2f, y, subPaint)
        y += 12f
        val s2 = "119, I. R. BELILIOUS LANE, HOWRAH-711101 (W.B.) INDIA"
        canvas.drawText(s2, (PAGE_WIDTH - subPaint.measureText(s2)) / 2f, y, subPaint)
        y += 20f

        // Undermentioned goods notice
        canvas.drawLine(left, y, right, y, strokePaint)
        y += 14f
        val notice = "Received the undermentioned goods in good order & condition as per your"
        canvas.drawText(notice, (PAGE_WIDTH - subPaint.measureText(notice)) / 2f, y, subPaint)
        y += 6f
        canvas.drawLine(left, y, right, y, strokePaint)
        y += 20f

        // Order No & Date
        canvas.drawText("Order No.", left + 10f, y, boldPaint)
        canvas.drawText(invoice.orderNo, left + 65f, y, textPaint)
        canvas.drawLine(left + 60f, y + 2f, left + 200f, y + 2f, thinStrokePaint)

        canvas.drawText("Date", right - 130f, y, boldPaint)
        canvas.drawText(IndianCurrencyWordConverter.formatDateToDDMMYYYY(invoice.orderDate), right - 95f, y, textPaint)
        canvas.drawLine(right - 100f, y + 2f, right - 10f, y + 2f, thinStrokePaint)
        y += 20f

        // Table (Cols: Qty (75), Description (flex), HSN (70), Rate (80), Amount (100))
        val tTop = y
        val tHeaderH = 22f
        canvas.drawLine(left, tTop, right, tTop, strokePaint)
        canvas.drawLine(left, tTop + tHeaderH, right, tTop + tHeaderH, strokePaint)
        
        val colQty = left + 75f
        val colHsn = right - 250f
        val colRate = right - 180f
        val colAmount = right - 100f

        fun drawChallanVLines(y1: Float, y2: Float) {
            canvas.drawLine(colQty, y1, colQty, y2, strokePaint)
            canvas.drawLine(colHsn, y1, colHsn, y2, strokePaint)
            canvas.drawLine(colRate, y1, colRate, y2, strokePaint)
            canvas.drawLine(colAmount, y1, colAmount, y2, strokePaint)
        }
        drawChallanVLines(tTop, tTop + tHeaderH)

        fun drawCenteredText(text: String, startX: Float, endX: Float, y: Float, paint: Paint) {
            var p = paint
            var w = p.measureText(text)
            val maxW = endX - startX - 4f
            if (w > maxW && maxW > 0) {
                p = Paint(paint)
                p.textSize = paint.textSize * (maxW / w)
                w = p.measureText(text)
            }
            canvas.drawText(text, startX + (endX - startX) / 2f - w / 2f, y, p)
        }
        
        fun drawRightText(text: String, endX: Float, y: Float, paint: Paint, maxW: Float) {
            var p = paint
            var w = p.measureText(text)
            if (w > maxW && maxW > 0) {
                p = Paint(paint)
                p.textSize = paint.textSize * (maxW / w)
                w = p.measureText(text)
            }
            canvas.drawText(text, endX - w - 4f, y, p)
        }

        drawCenteredText("Qty", left, colQty, tTop + 14f, boldPaint)
        drawCenteredText("DESCRIPTION OF GOODS", colQty, colHsn, tTop + 14f, boldPaint)
        drawCenteredText("HSN", colHsn, colRate, tTop + 14f, boldPaint)
        drawCenteredText("Rate (Rs.)", colRate, colAmount, tTop + 14f, boldPaint)
        drawCenteredText("AMOUNT (Rs.)", colAmount, right, tTop + 14f, boldPaint)

        // Rows (Matching Tax Invoice: default 10 items up to 15 items + 1 labour row)
        val tBottom = bottom - 80f
        val items = invoice.getItems()
        val displayItemRows = maxOf(10, minOf(15, items.size))
        val totalChallanRows = displayItemRows + 1
        val rowH = (tBottom - (tTop + tHeaderH)) / totalChallanRows

        val dynamicChallanTextSize = if (totalChallanRows <= 11) 11.5f else if (totalChallanRows <= 13) 10.5f else 9.5f
        textPaint.textSize = dynamicChallanTextSize
        boldPaint.textSize = dynamicChallanTextSize

        val italicPaint = Paint().apply {
            color = Color.BLACK
            textSize = dynamicChallanTextSize
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.ITALIC)
            isAntiAlias = true
            isLinearText = true
            isSubpixelText = true
        }

        fun drawLeftScaledText(text: String, startX: Float, y: Float, paint: Paint, maxW: Float) {
            var p = paint
            var w = p.measureText(text)
            if (w > maxW && maxW > 0) {
                p = Paint(paint)
                p.textSize = paint.textSize * (maxW / w)
            }
            canvas.drawText(text, startX, y, p)
        }

        var cY = tTop + tHeaderH

        // Row 0: Labour Charges
        canvas.drawLine(left, cY + rowH, right, cY + rowH, thinStrokePaint)
        drawChallanVLines(cY, cY + rowH)
        drawCenteredText("Nos", left, colQty, cY + rowH - 6f, italicPaint)
        drawLeftScaledText(invoice.labourChargesDescription, colQty + 6f, cY + rowH - 6f, textPaint, colHsn - colQty - 12f)
        drawCenteredText("Each", colHsn, colRate, cY + rowH - 6f, italicPaint)
        if (invoice.labourCharges > 0) {
            val lAmt = String.format(Locale.US, "%.2f", invoice.labourCharges)
            drawRightText(lAmt, right, cY + rowH - 6f, textPaint, right - colAmount)
        }
        cY += rowH

        // Item Rows + blank grid rows all the way to tBottom
        for (i in 0 until (totalChallanRows - 1)) {
            val nextY = if (i == totalChallanRows - 2) tBottom else cY + rowH
            canvas.drawLine(left, nextY, right, nextY, thinStrokePaint)
            drawChallanVLines(cY, nextY)

            if (i < items.size) {
                val item = items[i]
                if (item.quantity.isNotBlank() || item.description.isNotBlank() || item.rate.isNotBlank()) {
                    drawCenteredText(formatDisplayQuantity(item.quantity), left, colQty, cY + rowH - 6f, textPaint)
                    drawLeftScaledText(item.description, colQty + 6f, cY + rowH - 6f, textPaint, colHsn - colQty - 12f)
                    drawCenteredText(item.hsnCode, colHsn, colRate, cY + rowH - 6f, textPaint)
                    if (item.rate.isNotBlank()) {
                        drawCenteredText(item.rate, colRate, colAmount, cY + rowH - 6f, textPaint)
                    }
                    if (item.amount > 0) {
                        val aStr = String.format(Locale.US, "%.2f", item.amount)
                        drawRightText(aStr, right, cY + rowH - 6f, boldPaint, right - colAmount)
                    }
                }
            }
            cY = nextY
        }

        // Table Bottom
        canvas.drawLine(left, tBottom, right, tBottom, strokePaint)

        // Bottom Footer (GSTIN + Signatures)
        val bY = bottom - 50f
        val gstinStr = "GSTIN : 19AAEFP0503D1ZS"
        canvas.drawText(gstinStr, (PAGE_WIDTH - boldPaint.measureText(gstinStr)) / 2f, bY, boldPaint)

        val sigY = bottom - 18f
        canvas.drawLine(left + 20f, sigY - 14f, left + 180f, sigY - 14f, strokePaint)
        canvas.drawText("Receiver Signature", left + 50f, sigY, boldPaint)

        canvas.drawLine(right - 180f, sigY - 14f, right - 20f, sigY - 14f, strokePaint)
        canvas.drawText("Signature", right - 115f, sigY, boldPaint)

        // Final outer border pass to ensure crisp, uniform border all around
        canvas.drawRect(left, top, right, bottom, strokePaint)
    }

    // DRAWING SIMPLE ESTIMATE PAGE
    fun drawSimpleEstimatePage(
        canvas: Canvas,
        estimate: SimpleEstimateEntity,
        pageIndex: Int,
        totalPages: Int
    ) {
        canvas.drawColor(Color.WHITE)

        val strokePaint = Paint().apply {
            color = Color.BLACK
            style = Paint.Style.STROKE
            strokeWidth = 2f
        }
        val thinStrokePaint = Paint().apply {
            color = Color.BLACK
            style = Paint.Style.STROKE
            strokeWidth = 0.8f
        }
        val fillHeaderPaint = Paint().apply {
            color = Color.parseColor("#f3f4f6")
            style = Paint.Style.FILL
        }
        val textPaint = Paint().apply {
            color = Color.BLACK
            textSize = 9.5f
            isAntiAlias = true
            isLinearText = true
            isSubpixelText = true
        }
        val boldPaint = Paint().apply {
            color = Color.BLACK
            textSize = 9.5f
            typeface = Typeface.DEFAULT_BOLD
            isAntiAlias = true
            isLinearText = true
            isSubpixelText = true
        }
        val titlePaint = Paint().apply {
            color = Color.BLACK
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            isAntiAlias = true
            isLinearText = true
            isSubpixelText = true
        }

        val margin = 22f
        val left = margin
        val top = margin
        val right = PAGE_WIDTH - margin
        val bottom = PAGE_HEIGHT - margin

        canvas.drawRect(left, top, right, bottom, strokePaint)

        var y = top + 30f
        // Header
        val compName = estimate.companyName.ifBlank { "YOUR COMPANY NAME" }
        canvas.drawText(compName, (PAGE_WIDTH - titlePaint.measureText(compName)) / 2f, y, titlePaint)
        y += 24f

        canvas.drawText("Customer:", left + 10f, y, boldPaint)
        canvas.drawText(estimate.customerName, left + 65f, y, textPaint)
        canvas.drawLine(left + 60f, y + 3f, right - 160f, y + 3f, thinStrokePaint)

        val dateLabelX = right - 145f
        canvas.drawText("Date:", dateLabelX, y, boldPaint)
        val dateTextX = dateLabelX + boldPaint.measureText("Date:") + 5f
        canvas.drawText(IndianCurrencyWordConverter.formatDateToDDMMYYYY(estimate.date), dateTextX, y, textPaint)
        canvas.drawLine(dateTextX - 2f, y + 3f, right - 10f, y + 3f, thinStrokePaint)
        y += 16f

        canvas.drawLine(left, y, right, y, strokePaint)

        // Table Header
        val tTop = y
        val tH = 24f
        canvas.drawRect(left, tTop, right, tTop + tH, fillHeaderPaint)
        canvas.drawLine(left, tTop + tH, right, tTop + tH, strokePaint)

        val col1 = left + 70f
        val col2 = right - 160f
        val col3 = right - 85f

        fun drawEstVLines(y1: Float, y2: Float) {
            canvas.drawLine(col1, y1, col1, y2, strokePaint)
            canvas.drawLine(col2, y1, col2, y2, strokePaint)
            canvas.drawLine(col3, y1, col3, y2, strokePaint)
        }
        drawEstVLines(tTop, tTop + tH)

        canvas.drawText("Quantity", left + 15f, tTop + 16f, boldPaint)
        canvas.drawText("Description of Goods", col1 + 60f, tTop + 16f, boldPaint)
        canvas.drawText("Rate (Rs.)", col2 + 12f, tTop + 16f, boldPaint)
        canvas.drawText("Amount (Rs.)", col3 + 8f, tTop + 16f, boldPaint)

        val allItems = estimate.getItems()
        val startIndex = pageIndex * 12
        val pageItems = allItems.drop(startIndex).take(12)

        // Calculate balance forward and page total
        var balanceForward = 0.0
        for (i in 0 until startIndex) {
            if (i < allItems.size) {
                balanceForward += allItems[i].amount
            }
        }
        val thisPageItemsTotal = pageItems.sumOf { it.amount }
        val pageRunningTotal = balanceForward + thisPageItemsTotal

        var curY = tTop + tH
        val rowH = 26f

        // Row 1 on Page 1: "Nos", "", "Each", ""
        // Row 1 on subsequent pages: "", "Balance forward from Page X", "", balanceForward
        val italicPaint = Paint().apply {
            color = Color.BLACK
            textSize = 9f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.ITALIC)
            isAntiAlias = true
            isLinearText = true
            isSubpixelText = true
        }

        canvas.drawLine(left, curY + rowH, right, curY + rowH, strokePaint)
        drawEstVLines(curY, curY + rowH)
        if (pageIndex == 0) {
            canvas.drawText("Nos", left + 24f, curY + 17f, italicPaint)
            canvas.drawText("Each", col2 + 20f, curY + 17f, italicPaint)
        } else {
            val bfText = "Balance forward from Page $pageIndex"
            canvas.drawText(bfText, col2 - boldPaint.measureText(bfText) - 10f, curY + 17f, boldPaint)
            val bfStr = String.format(Locale.US, "%.2f", balanceForward)
            canvas.drawText(bfStr, right - boldPaint.measureText(bfStr) - 8f, curY + 17f, boldPaint)
        }
        curY += rowH

        fun drawEstScaledText(text: String, startX: Float, y: Float, paint: Paint, maxW: Float) {
            var p = paint
            var w = p.measureText(text)
            if (w > maxW && maxW > 0) {
                p = Paint(paint)
                p.textSize = paint.textSize * (maxW / w)
            }
            canvas.drawText(text, startX, y, p)
        }

        // 12 Items or filler rows
        for (i in 0 until 12) {
            canvas.drawLine(left, curY + rowH, right, curY + rowH, strokePaint)
            drawEstVLines(curY, curY + rowH)

            if (i < pageItems.size) {
                val item = pageItems[i]
                canvas.drawText(formatDisplayQuantity(item.quantity), left + 10f, curY + 17f, textPaint)
                drawEstScaledText(item.description, col1 + 8f, curY + 17f, textPaint, col2 - col1 - 16f)
                if (item.rate.isNotBlank()) {
                    canvas.drawText(item.rate, col3 - textPaint.measureText(item.rate) - 8f, curY + 17f, textPaint)
                }
                if (item.amount > 0) {
                    val aStr = String.format(Locale.US, "%.2f", item.amount)
                    canvas.drawText(aStr, right - boldPaint.measureText(aStr) - 8f, curY + 17f, boldPaint)
                }
            }
            curY += rowH
        }

        // Table Bottom
        canvas.drawLine(left, curY, right, curY, strokePaint)

        // Footer: Signature & TOTAL
        val footY = curY + 35f
        canvas.drawText("Signature: __________________________", left + 10f, footY, boldPaint)

        val totalBoxLeft = col2
        val totalBoxRight = right
        canvas.drawRect(totalBoxLeft, curY, totalBoxRight, curY + 36f, fillHeaderPaint)
        canvas.drawLine(totalBoxLeft, curY, totalBoxLeft, curY + 36f, strokePaint)
        canvas.drawLine(totalBoxLeft, curY + 36f, totalBoxRight, curY + 36f, strokePaint)

        canvas.drawText("TOTAL:", totalBoxLeft + 8f, curY + 22f, boldPaint)
        val totStr = "Rs. " + String.format(Locale.US, "%.2f", pageRunningTotal)
        canvas.drawText(totStr, totalBoxRight - boldPaint.measureText(totStr) - 8f, curY + 22f, boldPaint)

        // Page number
        val pageNumStr = "Page ${pageIndex + 1} of $totalPages"
        val pageNumPaint = Paint().apply {
            color = Color.GRAY
            textSize = 8.5f
            isAntiAlias = true
            isLinearText = true
            isSubpixelText = true
        }
        canvas.drawText(pageNumStr, (PAGE_WIDTH - pageNumPaint.measureText(pageNumStr)) / 2f, bottom - 10f, pageNumPaint)

        // Final outer border pass
        canvas.drawRect(left, top, right, bottom, strokePaint)
    }
}
