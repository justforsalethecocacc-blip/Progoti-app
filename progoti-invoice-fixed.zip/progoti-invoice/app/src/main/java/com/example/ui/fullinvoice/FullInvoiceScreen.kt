package com.example.ui.fullinvoice

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.InvoiceItem
import com.example.ui.components.AppDatePickerField
import com.example.ui.components.AppSectionHeader
import com.example.util.InvoicePdfGenerator
import com.example.viewmodel.InvoiceViewModel
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FullInvoiceScreen(
    viewModel: InvoiceViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val invoice by viewModel.fullInvoice.collectAsState()
    val items by viewModel.fullInvoiceItems.collectAsState()
    val totals = viewModel.getFullInvoiceTotals()

    var selectedTab by remember { mutableIntStateOf(0) }
    var showResetDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Full Invoice & Challan",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = (if (invoice.invoiceNo.isNotBlank()) "Inv #${invoice.invoiceNo}" else "New Invoice") + " • v1.2 (Max 15 Items)",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("full_invoice_back_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showResetDialog = true },
                        modifier = Modifier.testTag("full_invoice_reset_button")
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Reset")
                    }
                    IconButton(
                        onClick = {
                            viewModel.saveFullInvoice {
                                Toast.makeText(context, "Invoice saved successfully!", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.testTag("full_invoice_save_button")
                    ) {
                        Icon(Icons.Default.Save, contentDescription = "Save")
                    }
                    IconButton(
                        onClick = {
                            InvoicePdfGenerator.shareFullInvoicePdf(context, invoice.copy(itemsJson = com.example.data.model.FullInvoiceEntity.itemsToJson(items)))
                        },
                        modifier = Modifier.testTag("full_invoice_share_button")
                    ) {
                        Icon(Icons.Default.Share, contentDescription = "Share PDF")
                    }
                    IconButton(
                        onClick = {
                            InvoicePdfGenerator.printFullInvoice(context, invoice.copy(itemsJson = com.example.data.model.FullInvoiceEntity.itemsToJson(items)))
                        },
                        modifier = Modifier.testTag("full_invoice_print_button")
                    ) {
                        Icon(Icons.Default.Print, contentDescription = "Print")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            PrimaryTabRow(selectedTabIndex = selectedTab) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Mobile Entry") },
                    icon = { Icon(Icons.Default.Edit, contentDescription = null) },
                    modifier = Modifier.testTag("full_invoice_tab_entry")
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Tax Invoice") },
                    icon = { Icon(Icons.Default.Receipt, contentDescription = null) },
                    modifier = Modifier.testTag("full_invoice_tab_preview")
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("Challan") },
                    icon = { Icon(Icons.Default.LocalShipping, contentDescription = null) },
                    modifier = Modifier.testTag("full_invoice_tab_challan")
                )
            }

            when (selectedTab) {
                0 -> {
                    // Mobile Entry
                    FullInvoiceDataEntryView(
                        invoice = invoice,
                        items = items,
                        totals = totals,
                        onUpdateInvoice = { viewModel.updateFullInvoiceField(it) },
                        onAddItem = { viewModel.addFullInvoiceItem() },
                        onRemoveItem = { viewModel.removeFullInvoiceItem(it) },
                        onUpdateItem = { id, q, d, h, r -> viewModel.updateFullInvoiceItem(id, q, d, h, r) },
                        onAppendMm = { viewModel.appendMmToItem(it) },
                        onSwitchToPreview = { selectedTab = 1 },
                        onPrint = {
                            InvoicePdfGenerator.printFullInvoice(
                                context,
                                invoice.copy(itemsJson = com.example.data.model.FullInvoiceEntity.itemsToJson(items))
                            )
                        }
                    )
                }
                1 -> {
                    // Tax Invoice Document Preview
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(12.dp)
                    ) {
                        FullInvoiceDocumentPreview(
                            invoice = invoice.copy(itemsJson = com.example.data.model.FullInvoiceEntity.itemsToJson(items)),
                            totals = totals,
                            onCopyToggle = { copyType, checked ->
                                viewModel.updateFullInvoiceField {
                                    when (copyType) {
                                        "original" -> it.copy(copyOriginal = checked)
                                        "duplicate" -> it.copy(copyDuplicate = checked)
                                        "seller" -> it.copy(copySeller = checked)
                                        "transporter" -> it.copy(copyTransporter = checked)
                                        else -> it
                                    }
                                }
                            }
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = {
                                    InvoicePdfGenerator.printFullInvoice(
                                        context,
                                        invoice.copy(itemsJson = com.example.data.model.FullInvoiceEntity.itemsToJson(items))
                                    )
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("preview_print_invoice_btn")
                            ) {
                                Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Print Document")
                            }

                            OutlinedButton(
                                onClick = {
                                    InvoicePdfGenerator.shareFullInvoicePdf(
                                        context,
                                        invoice.copy(itemsJson = com.example.data.model.FullInvoiceEntity.itemsToJson(items))
                                    )
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("preview_share_invoice_btn")
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Share PDF")
                            }
                        }
                    }
                }
                2 -> {
                    // Challan Document Preview
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(12.dp)
                    ) {
                        FullChallanDocumentPreview(
                            invoice = invoice.copy(itemsJson = com.example.data.model.FullInvoiceEntity.itemsToJson(items))
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = {
                                    InvoicePdfGenerator.printFullInvoice(
                                        context,
                                        invoice.copy(itemsJson = com.example.data.model.FullInvoiceEntity.itemsToJson(items))
                                    )
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("preview_print_challan_btn")
                            ) {
                                Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Print Challan")
                            }

                            OutlinedButton(
                                onClick = {
                                    InvoicePdfGenerator.shareFullInvoicePdf(
                                        context,
                                        invoice.copy(itemsJson = com.example.data.model.FullInvoiceEntity.itemsToJson(items))
                                    )
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("preview_share_challan_btn")
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Share PDF")
                            }
                        }
                    }
                }
            }
        }
    }

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = { Text("Reset Invoice?") },
            text = { Text("This will clear all entered fields and reset items. Are you sure?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.resetFullInvoice()
                        showResetDialog = false
                    },
                    modifier = Modifier.testTag("confirm_reset_invoice_btn")
                ) {
                    Text("Reset", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun FullInvoiceDataEntryView(
    invoice: com.example.data.model.FullInvoiceEntity,
    items: List<InvoiceItem>,
    totals: com.example.viewmodel.FullInvoiceTotals,
    onUpdateInvoice: ((com.example.data.model.FullInvoiceEntity) -> com.example.data.model.FullInvoiceEntity) -> Unit,
    onAddItem: () -> Unit,
    onRemoveItem: (Long) -> Unit,
    onUpdateItem: (Long, String?, String?, String?, String?) -> Unit,
    onAppendMm: (Long) -> Unit,
    onSwitchToPreview: () -> Unit,
    onPrint: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Section: Document References
        AppSectionHeader(title = "Document Reference Numbers & Dates")
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = invoice.invoiceNo,
                onValueChange = { v -> onUpdateInvoice { it.copy(invoiceNo = v) } },
                label = { Text("Invoice No.") },
                modifier = Modifier.weight(1f).testTag("invoice_no_field"),
                singleLine = true
            )
            AppDatePickerField(
                label = "Invoice Date",
                value = invoice.invoiceDate,
                onDateSelected = { d -> onUpdateInvoice { it.copy(invoiceDate = d) } },
                modifier = Modifier.weight(1f),
                testTag = "invoice_date_field"
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = invoice.challanNo,
                onValueChange = { v -> onUpdateInvoice { it.copy(challanNo = v) } },
                label = { Text("Challan No.") },
                modifier = Modifier.weight(1f).testTag("challan_no_field"),
                singleLine = true
            )
            AppDatePickerField(
                label = "Challan Date",
                value = invoice.challanDate,
                onDateSelected = { d -> onUpdateInvoice { it.copy(challanDate = d) } },
                modifier = Modifier.weight(1f),
                testTag = "challan_date_field"
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = invoice.orderNo,
                onValueChange = { v -> onUpdateInvoice { it.copy(orderNo = v) } },
                label = { Text("Order No.") },
                modifier = Modifier.weight(1f).testTag("order_no_field"),
                singleLine = true
            )
            AppDatePickerField(
                label = "Order Date",
                value = invoice.orderDate,
                onDateSelected = { d -> onUpdateInvoice { it.copy(orderDate = d) } },
                modifier = Modifier.weight(1f),
                testTag = "order_date_field"
            )
        }

        // Section: Receiver Details
        AppSectionHeader(title = "Receiver Details (Billed to)")
        OutlinedTextField(
            value = invoice.customerName,
            onValueChange = { v -> onUpdateInvoice { it.copy(customerName = v) } },
            label = { Text("Customer / Receiver Name") },
            modifier = Modifier.fillMaxWidth().testTag("customer_name_field"),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = invoice.customerAddress,
            onValueChange = { v -> onUpdateInvoice { it.copy(customerAddress = v) } },
            label = { Text("Customer Address") },
            modifier = Modifier.fillMaxWidth().testTag("customer_address_field"),
            minLines = 2,
            maxLines = 3
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = invoice.customerGSTIN,
            onValueChange = { v -> onUpdateInvoice { it.copy(customerGSTIN = v.uppercase()) } },
            label = { Text("Customer GSTIN") },
            modifier = Modifier.fillMaxWidth().testTag("customer_gstin_field"),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = invoice.customerState,
                onValueChange = { v -> onUpdateInvoice { it.copy(customerState = v) } },
                label = { Text("State") },
                modifier = Modifier.weight(1.2f).testTag("customer_state_field"),
                singleLine = true
            )
            OutlinedTextField(
                value = invoice.customerStateCode,
                onValueChange = { v -> onUpdateInvoice { it.copy(customerStateCode = v) } },
                label = { Text("State Code") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(0.8f).testTag("customer_state_code_field"),
                singleLine = true
            )
        }

        // Section: Transportation
        AppSectionHeader(title = "Transportation & Vehicle")
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = invoice.transportationMode,
                onValueChange = { v -> onUpdateInvoice { it.copy(transportationMode = v) } },
                label = { Text("Transportation Mode") },
                modifier = Modifier.weight(1f).testTag("transportation_mode_field"),
                singleLine = true
            )
            OutlinedTextField(
                value = invoice.vehicleNumber,
                onValueChange = { v -> onUpdateInvoice { it.copy(vehicleNumber = v) } },
                label = { Text("Vehicle Number") },
                modifier = Modifier.weight(1f).testTag("vehicle_number_field"),
                singleLine = true
            )
        }

        // Section: Copy Checkboxes
        AppSectionHeader(title = "Document Copies (Check to mark)")
        Row(modifier = Modifier.fillMaxWidth()) {
            Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                Checkbox(
                    checked = invoice.copyOriginal,
                    onCheckedChange = { c -> onUpdateInvoice { it.copy(copyOriginal = c) } },
                    modifier = Modifier.testTag("checkbox_copy_original")
                )
                Text("Original", fontSize = 12.sp)
            }
            Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                Checkbox(
                    checked = invoice.copyDuplicate,
                    onCheckedChange = { c -> onUpdateInvoice { it.copy(copyDuplicate = c) } },
                    modifier = Modifier.testTag("checkbox_copy_duplicate")
                )
                Text("Duplicate", fontSize = 12.sp)
            }
        }
        Row(modifier = Modifier.fillMaxWidth()) {
            Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                Checkbox(
                    checked = invoice.copySeller,
                    onCheckedChange = { c -> onUpdateInvoice { it.copy(copySeller = c) } },
                    modifier = Modifier.testTag("checkbox_copy_seller")
                )
                Text("Seller", fontSize = 12.sp)
            }
            Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                Checkbox(
                    checked = invoice.copyTransporter,
                    onCheckedChange = { c -> onUpdateInvoice { it.copy(copyTransporter = c) } },
                    modifier = Modifier.testTag("checkbox_copy_transporter")
                )
                Text("Transporter", fontSize = 12.sp)
            }
        }

        // Section: Labour Charges & Tax Rates
        AppSectionHeader(title = "Labour Charges & GST Rates")
        OutlinedTextField(
            value = invoice.labourChargesDescription,
            onValueChange = { v -> onUpdateInvoice { it.copy(labourChargesDescription = v) } },
            label = { Text("Labour Charges Description") },
            modifier = Modifier.fillMaxWidth().testTag("labour_desc_field")
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = if (invoice.labourCharges > 0) invoice.labourCharges.toString() else "",
            onValueChange = { v ->
                val amt = v.toDoubleOrNull() ?: 0.0
                onUpdateInvoice { it.copy(labourCharges = amt) }
            },
            label = { Text("Labour Charges (Rs.)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            modifier = Modifier.fillMaxWidth().testTag("labour_charges_field"),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = invoice.cgstRate.toString(),
                onValueChange = { v ->
                    val r = v.toDoubleOrNull() ?: 0.0
                    onUpdateInvoice { it.copy(cgstRate = r) }
                },
                label = { Text("CGST %") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.weight(1f).testTag("cgst_rate_field"),
                singleLine = true
            )
            OutlinedTextField(
                value = invoice.sgstRate.toString(),
                onValueChange = { v ->
                    val r = v.toDoubleOrNull() ?: 0.0
                    onUpdateInvoice { it.copy(sgstRate = r) }
                },
                label = { Text("SGST %") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.weight(1f).testTag("sgst_rate_field"),
                singleLine = true
            )
            OutlinedTextField(
                value = invoice.igstRate.toString(),
                onValueChange = { v ->
                    val r = v.toDoubleOrNull() ?: 0.0
                    onUpdateInvoice { it.copy(igstRate = r) }
                },
                label = { Text("IGST %") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.weight(1f).testTag("igst_rate_field"),
                singleLine = true
            )
        }

        // Section: Items
        AppSectionHeader(
            title = "Invoice Items (${items.size}/8)",
            subtitle = "Add up to 8 items as supported by the official A4 document layout"
        )

        items.forEachIndexed { index, item ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
                    .testTag("invoice_item_card_$index"),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                shape = RoundedCornerShape(8.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Item #${index + 1}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        if (items.size > 1) {
                            IconButton(
                                onClick = { onRemoveItem(item.id) },
                                modifier = Modifier.size(32.dp).testTag("delete_item_btn_$index")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "Remove Item",
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = item.quantity,
                            onValueChange = { onUpdateItem(item.id, it, null, null, null) },
                            label = { Text("Qty") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f).testTag("item_qty_$index"),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = item.rate,
                            onValueChange = { onUpdateItem(item.id, null, null, null, it) },
                            label = { Text("Rate (Rs.)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f).testTag("item_rate_$index"),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = item.hsnCode,
                            onValueChange = { onUpdateItem(item.id, null, null, it, null) },
                            label = { Text("HSN Code") },
                            modifier = Modifier.weight(1f).testTag("item_hsn_$index"),
                            singleLine = true
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = item.description,
                            onValueChange = { onUpdateItem(item.id, null, it, null, null) },
                            label = { Text("Description of Goods") },
                            modifier = Modifier.weight(1f).testTag("item_desc_$index"),
                            singleLine = true
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Button(
                            onClick = { onAppendMm(item.id) },
                            modifier = Modifier.testTag("item_append_mm_btn_$index"),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text("+mm")
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        Text(
                            text = "Amount: ₹" + String.format(Locale.US, "%.2f", item.amount),
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = onAddItem,
            enabled = items.size < 15,
            modifier = Modifier.fillMaxWidth().testTag("add_item_button"),
            shape = RoundedCornerShape(8.dp)
        ) {
            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(if (items.size < 15) "+ Add New Item (${items.size}/15)" else "Item Limit Reached (15/15)")
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Calculations & Totals Card
        Card(
            modifier = Modifier.fillMaxWidth().testTag("invoice_totals_summary_card"),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Tax & Totals Breakdown",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(modifier = Modifier.height(8.dp))

                TotalBreakdownRow("Items Total:", "₹" + String.format(Locale.US, "%.2f", totals.itemsTotal))
                TotalBreakdownRow("Labour Charges:", "₹" + String.format(Locale.US, "%.2f", invoice.labourCharges))
                TotalBreakdownRow("Taxable Value:", "₹" + String.format(Locale.US, "%.2f", totals.taxableValue), isBold = true)
                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                TotalBreakdownRow("CGST @ ${invoice.cgstRate}%:", "₹" + String.format(Locale.US, "%.2f", totals.cgstAmount))
                TotalBreakdownRow("SGST @ ${invoice.sgstRate}%:", "₹" + String.format(Locale.US, "%.2f", totals.sgstAmount))
                if (invoice.igstRate > 0) {
                    TotalBreakdownRow("IGST @ ${invoice.igstRate}%:", "₹" + String.format(Locale.US, "%.2f", totals.igstAmount))
                }
                TotalBreakdownRow("Total Tax:", "₹" + String.format(Locale.US, "%.2f", totals.totalTax))
                val roundPrefix = if (totals.roundedOff > 0) "+" else ""
                TotalBreakdownRow("Rounded off (+/-):", roundPrefix + String.format(Locale.US, "%.2f", totals.roundedOff))
                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                TotalBreakdownRow(
                    "FINAL TOTAL:",
                    "₹" + String.format(Locale.US, "%.2f", totals.finalTotal),
                    isBold = true,
                    highlight = true
                )

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Rupees in words: ${totals.words}",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = onSwitchToPreview,
                modifier = Modifier.weight(1f).testTag("bottom_switch_to_preview_btn")
            ) {
                Text("View Tax Invoice")
            }
            OutlinedButton(
                onClick = onPrint,
                modifier = Modifier.weight(1f).testTag("bottom_print_direct_btn")
            ) {
                Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Print / PDF")
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
private fun TotalBreakdownRow(
    label: String,
    value: String,
    isBold: Boolean = false,
    highlight: Boolean = false
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal,
            fontSize = if (highlight) 15.sp else 13.sp,
            color = if (highlight) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = value,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal,
            fontSize = if (highlight) 15.sp else 13.sp,
            color = if (highlight) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
        )
    }
}
