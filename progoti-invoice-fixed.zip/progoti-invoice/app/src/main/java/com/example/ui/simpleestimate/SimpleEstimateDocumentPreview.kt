package com.example.ui.simpleestimate

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import com.example.data.model.SimpleEstimateEntity
import com.example.util.InvoicePdfGenerator

@Composable
fun SimpleEstimateDocumentPreview(
    estimate: SimpleEstimateEntity,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(Color.White)
            .testTag("simple_estimate_document_preview")
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(595f / 842f)
        ) {
            val scaleX = size.width / 595f
            val scaleY = size.height / 842f

            drawContext.canvas.nativeCanvas.apply {
                save()
                scale(scaleX, scaleY)
                InvoicePdfGenerator.drawSimpleEstimatePage(this, estimate, 0, 1)
                restore()
            }
        }
    }
}
