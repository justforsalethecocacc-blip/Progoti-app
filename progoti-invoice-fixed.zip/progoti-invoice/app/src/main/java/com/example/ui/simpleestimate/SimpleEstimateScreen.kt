package com.example.ui.simpleestimate

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.EstimateItem
import com.example.data.model.SimpleEstimateEntity
import com.example.ui.components.AppDatePickerField
import com.example.ui.components.AppSectionHeader
import com.example.util.InvoicePdfGenerator
import com.example.viewmodel.InvoiceViewModel
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SimpleEstimateScreen(
    viewModel: InvoiceViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val estimate by viewModel.simpleEstimate.collectAsState()
    val items by viewModel.estimateItems.collectAsState()
    val total = viewModel.getEstimateTotal()

    var selectedTab by remember { mutableIntStateOf(0) }
    var showResetDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Simple Invoice",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (estimate.customerName.isNotBlank()) estimate.customerName else "New Estimate",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("simple_estimate_back_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showResetDialog = true },
                        modifier = Modifier.testTag("simple_estimate_reset_button")
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Reset")
                    }
                    IconButton(
                        onClick = {
                            viewModel.saveSimpleEstimate {
                                Toast.makeText(context, "Simple Invoice saved successfully!", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.testTag("simple_estimate_save_button")
                    ) {
                        Icon(Icons.Default.Save, contentDescription = "Save")
                    }
                    IconButton(
                        onClick = {
                            InvoicePdfGenerator.shareSimpleEstimatePdf(
                                context,
                                estimate.copy(itemsJson = SimpleEstimateEntity.itemsToJson(items))
                            )
                        },
                        modifier = Modifier.testTag("simple_estimate_share_button")
                    ) {
                        Icon(Icons.Default.Share, contentDescription = "Share PDF")
                    }
                    IconButton(
                        onClick = {
                            InvoicePdfGenerator.printSimpleEstimate(
                                context,
                                estimate.copy(itemsJson = SimpleEstimateEntity.itemsToJson(items))
                            )
                        },
                        modifier = Modifier.testTag("simple_estimate_print_button")
                    ) {
                        Icon(Icons.Default.Print, contentDescription = "Print")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            PrimaryTabRow(selectedTabIndex = selectedTab) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Mobile Entry") },
                    icon = { Icon(Icons.Default.Edit, contentDescription = null) },
                    modifier = Modifier.testTag("simple_estimate_tab_entry")
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Document Preview") },
                    icon = { Icon(Icons.Default.Description, contentDescription = null) },
                    modifier = Modifier.testTag("simple_estimate_tab_preview")
                )
            }

            when (selectedTab) {
                0 -> {
                    // Mobile Entry
                    SimpleEstimateDataEntryView(
                        estimate = estimate,
                        items = items,
                        total = total,
                        onUpdateEstimate = { viewModel.updateEstimateField(it) },
                        onAddItem = { viewModel.addEstimateItem() },
                        onRemoveItem = { viewModel.removeEstimateItem(it) },
                        onUpdateItem = { id, q, d, r -> viewModel.updateEstimateItem(id, q, d, r) },
                        onToggleTag = { id, tag -> viewModel.toggleEstimateTag(id, tag) },
                        onSwitchToPreview = { selectedTab = 1 },
                        onPrint = {
                            InvoicePdfGenerator.printSimpleEstimate(
                                context,
                                estimate.copy(itemsJson = SimpleEstimateEntity.itemsToJson(items))
                            )
                        }
                    )
                }
                1 -> {
                    // Document Preview
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(12.dp)
                    ) {
                        SimpleEstimateDocumentPreview(
                            estimate = estimate.copy(itemsJson = SimpleEstimateEntity.itemsToJson(items))
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = {
                                    InvoicePdfGenerator.printSimpleEstimate(
                                        context,
                                        estimate.copy(itemsJson = SimpleEstimateEntity.itemsToJson(items))
                                    )
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("preview_print_estimate_btn")
                            ) {
                                Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Print Document")
                            }

                            OutlinedButton(
                                onClick = {
                                    InvoicePdfGenerator.shareSimpleEstimatePdf(
                                        context,
                                        estimate.copy(itemsJson = SimpleEstimateEntity.itemsToJson(items))
                                    )
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("preview_share_estimate_btn")
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Share PDF")
                            }
                        }
                    }
                }
            }
        }
    }

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = { Text("Reset Simple Invoice?") },
            text = { Text("This will clear all entered items and details. Are you sure?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.resetSimpleEstimate()
                        showResetDialog = false
                    },
                    modifier = Modifier.testTag("confirm_reset_estimate_btn")
                ) {
                    Text("Reset", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun SimpleEstimateDataEntryView(
    estimate: SimpleEstimateEntity,
    items: List<EstimateItem>,
    total: Double,
    onUpdateEstimate: ((SimpleEstimateEntity) -> SimpleEstimateEntity) -> Unit,
    onAddItem: () -> Unit,
    onRemoveItem: (Long) -> Unit,
    onUpdateItem: (Long, String?, String?, String?) -> Unit,
    onToggleTag: (Long, String) -> Unit,
    onSwitchToPreview: () -> Unit,
    onPrint: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Company & Customer
        AppSectionHeader(title = "Header & Customer Information")

        OutlinedTextField(
            value = estimate.companyName,
            onValueChange = { v -> onUpdateEstimate { it.copy(companyName = v) } },
            label = { Text("Company Name") },
            modifier = Modifier.fillMaxWidth().testTag("estimate_company_name_field"),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = estimate.customerName,
                onValueChange = { v -> onUpdateEstimate { it.copy(customerName = v) } },
                label = { Text("Customer Name") },
                modifier = Modifier.weight(1.2f).testTag("estimate_customer_name_field"),
                singleLine = true
            )
            AppDatePickerField(
                label = "Date",
                value = estimate.date,
                onDateSelected = { d -> onUpdateEstimate { it.copy(date = d) } },
                modifier = Modifier.weight(0.8f),
                testTag = "estimate_date_field"
            )
        }

        // Items Section
        AppSectionHeader(
            title = "Items (${items.size})",
            subtitle = "12 items per page with automatic multi-page calculation"
        )

        items.forEachIndexed { index, item ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
                    .testTag("estimate_item_card_$index"),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                shape = RoundedCornerShape(8.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Item #${index + 1}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        if (items.size > 1) {
                            IconButton(
                                onClick = { onRemoveItem(item.id) },
                                modifier = Modifier.size(32.dp).testTag("estimate_delete_item_btn_$index")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "Remove Item",
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = item.quantity,
                            onValueChange = { onUpdateItem(item.id, it, null, null) },
                            label = { Text("Qty") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f).testTag("estimate_qty_$index"),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = item.rate,
                            onValueChange = { onUpdateItem(item.id, null, null, it) },
                            label = { Text("Rate (Rs.)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f).testTag("estimate_rate_$index"),
                            singleLine = true
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = item.description,
                        onValueChange = { onUpdateItem(item.id, null, it, null) },
                        label = { Text("Description of Goods") },
                        modifier = Modifier.fillMaxWidth().testTag("estimate_desc_$index"),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Tags row: Drill, Pipe, Oval, BL
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        FilterChip(
                            selected = item.drill,
                            onClick = { onToggleTag(item.id, "drill") },
                            label = { Text("Drill", fontSize = 11.sp) },
                            modifier = Modifier.testTag("tag_drill_$index")
                        )
                        FilterChip(
                            selected = item.pipe,
                            onClick = { onToggleTag(item.id, "pipe") },
                            label = { Text("Pipe", fontSize = 11.sp) },
                            modifier = Modifier.testTag("tag_pipe_$index")
                        )
                        FilterChip(
                            selected = item.oval,
                            onClick = { onToggleTag(item.id, "oval") },
                            label = { Text("Oval", fontSize = 11.sp) },
                            modifier = Modifier.testTag("tag_oval_$index")
                        )
                        FilterChip(
                            selected = item.bl,
                            onClick = { onToggleTag(item.id, "bl") },
                            label = { Text("BL", fontSize = 11.sp) },
                            modifier = Modifier.testTag("tag_bl_$index")
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        Text(
                            text = "Amount: ₹" + String.format(Locale.US, "%.2f", item.amount),
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = onAddItem,
            modifier = Modifier.fillMaxWidth().testTag("estimate_add_item_button"),
            shape = RoundedCornerShape(8.dp)
        ) {
            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("+ Add New Item (${items.size})")
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Totals Card
        Card(
            modifier = Modifier.fillMaxWidth().testTag("estimate_totals_card"),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "TOTAL ESTIMATE:",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        text = "₹" + String.format(Locale.US, "%.2f", total),
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                val totalPages = kotlin.math.max(1, (items.size + 11) / 12)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Generates $totalPages printed page${if (totalPages > 1) "s" else ""}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = onSwitchToPreview,
                modifier = Modifier.weight(1f).testTag("bottom_switch_to_estimate_preview_btn")
            ) {
                Text("View Document Preview")
            }
            OutlinedButton(
                onClick = onPrint,
                modifier = Modifier.weight(1f).testTag("bottom_print_estimate_direct_btn")
            ) {
                Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Print / PDF")
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}
