package com.example.util

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToLong

object IndianCurrencyWordConverter {
    private val ones = arrayOf("", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine")
    private val tens = arrayOf("", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety")
    private val teens = arrayOf("Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen")

    private fun convertHundreds(nOriginal: Long): String {
        var n = nOriginal
        var str = ""
        if (n > 99) {
            str += ones[(n / 100).toInt()] + " Hundred "
            n %= 100
        }
        if (n > 19) {
            str += tens[(n / 10).toInt()] + " "
            n %= 10
        } else if (n >= 10) {
            str += teens[(n - 10).toInt()] + " "
            return str
        }
        if (n > 0) {
            str += ones[n.toInt()] + " "
        }
        return str
    }

    fun convert(num: Double): String {
        val rounded = num.roundToLong()
        if (rounded == 0L) return "Zero"

        val absNum = abs(rounded)
        var tempNum = absNum
        val sb = StringBuilder()

        if (tempNum >= 10000000L) {
            sb.append(convertHundreds(tempNum / 10000000L)).append("Crore ")
            tempNum %= 10000000L
        }
        if (tempNum >= 100000L) {
            sb.append(convertHundreds(tempNum / 100000L)).append("Lakh ")
            tempNum %= 100000L
        }
        if (tempNum >= 1000L) {
            sb.append(convertHundreds(tempNum / 1000L)).append("Thousand ")
            tempNum %= 1000L
        }
        sb.append(convertHundreds(tempNum))

        val word = sb.toString().trim()
        return (if (num < 0) "Minus " else "") + word + " Only"
    }

    fun formatDateToDDMMYYYY(isoDate: String): String {
        if (isoDate.isBlank()) return ""
        val parts = isoDate.split("-")
        if (parts.size == 3 && parts[0].length == 4) {
            return "${parts[2]}/${parts[1]}/${parts[0]}"
        }
        return isoDate
    }

    fun getCurrentDateIso(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return sdf.format(Date())
    }
}
