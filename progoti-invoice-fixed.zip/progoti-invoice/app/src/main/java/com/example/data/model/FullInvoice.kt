package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import org.json.JSONArray
import org.json.JSONObject

data class InvoiceItem(
    val id: Long = System.currentTimeMillis(),
    val quantity: String = "",
    val description: String = "",
    val hsnCode: String = "",
    val rate: String = "",
    val amount: Double = 0.0
) {
    fun calculateAmount(): Double {
        val qty = quantity.toDoubleOrNull() ?: 0.0
        val r = rate.toDoubleOrNull() ?: 0.0
        return if (qty > 0 && r > 0) qty * r else 0.0
    }
}

@Entity(tableName = "full_invoices")
data class FullInvoiceEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val invoiceNo: String = "",
    val invoiceDate: String = "",
    val challanNo: String = "",
    val challanDate: String = "",
    val orderNo: String = "",
    val orderDate: String = "",
    val customerName: String = "",
    val customerAddress: String = "",
    val customerGSTIN: String = "",
    val customerState: String = "West Bengal",
    val customerStateCode: String = "19",
    val transportationMode: String = "",
    val vehicleNumber: String = "",
    val labourChargesDescription: String = "Labour Charges For Machining & Straightening",
    val labourCharges: Double = 0.0,
    val cgstRate: Double = 9.0,
    val sgstRate: Double = 9.0,
    val igstRate: Double = 0.0,
    val itemsJson: String = "[]",
    val copyOriginal: Boolean = false,
    val copyDuplicate: Boolean = false,
    val copySeller: Boolean = false,
    val copyTransporter: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
) {
    fun getItems(): List<InvoiceItem> {
        val list = mutableListOf<InvoiceItem>()
        try {
            val arr = JSONArray(itemsJson)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    InvoiceItem(
                        id = obj.optLong("id", System.currentTimeMillis() + i),
                        quantity = obj.optString("quantity", ""),
                        description = obj.optString("description", ""),
                        hsnCode = obj.optString("hsnCode", ""),
                        rate = obj.optString("rate", ""),
                        amount = obj.optDouble("amount", 0.0)
                    )
                )
            }
        } catch (_: Exception) {
        }
        if (list.isEmpty()) {
            list.add(InvoiceItem())
        }
        return list
    }

    companion object {
        fun itemsToJson(items: List<InvoiceItem>): String {
            val arr = JSONArray()
            for (item in items) {
                val obj = JSONObject()
                obj.put("id", item.id)
                obj.put("quantity", item.quantity)
                obj.put("description", item.description)
                obj.put("hsnCode", item.hsnCode)
                obj.put("rate", item.rate)
                obj.put("amount", item.amount)
                arr.put(obj)
            }
            return arr.toString()
        }
    }
}
