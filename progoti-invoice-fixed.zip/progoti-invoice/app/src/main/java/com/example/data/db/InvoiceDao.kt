package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.FullInvoiceEntity
import com.example.data.model.SimpleEstimateEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface InvoiceDao {
    @Query("SELECT * FROM full_invoices ORDER BY updatedAt DESC")
    fun getAllFullInvoices(): Flow<List<FullInvoiceEntity>>

    @Query("SELECT * FROM full_invoices WHERE id = :id LIMIT 1")
    suspend fun getFullInvoiceById(id: Long): FullInvoiceEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFullInvoice(invoice: FullInvoiceEntity): Long

    @Query("DELETE FROM full_invoices WHERE id = :id")
    suspend fun deleteFullInvoiceById(id: Long)

    @Query("SELECT * FROM simple_estimates ORDER BY updatedAt DESC")
    fun getAllSimpleEstimates(): Flow<List<SimpleEstimateEntity>>

    @Query("SELECT * FROM simple_estimates WHERE id = :id LIMIT 1")
    suspend fun getSimpleEstimateById(id: Long): SimpleEstimateEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSimpleEstimate(estimate: SimpleEstimateEntity): Long

    @Query("DELETE FROM simple_estimates WHERE id = :id")
    suspend fun deleteSimpleEstimateById(id: Long)
}
