package com.example.ui.fullinvoice

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import com.example.data.model.FullInvoiceEntity
import com.example.util.InvoicePdfGenerator

@Composable
fun FullChallanDocumentPreview(
    invoice: FullInvoiceEntity,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(Color.White)
            .testTag("full_challan_document_preview")
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(595f / 842f)
        ) {
            val scaleX = size.width / 595f
            val scaleY = size.height / 842f

            drawContext.canvas.nativeCanvas.apply {
                save()
                scale(scaleX, scaleY)
                InvoicePdfGenerator.drawDeliveryChallanPage(context, this, invoice)
                restore()
            }
        }
    }
}
