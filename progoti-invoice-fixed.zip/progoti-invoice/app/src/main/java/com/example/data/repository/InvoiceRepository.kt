package com.example.data.repository

import com.example.data.db.InvoiceDao
import com.example.data.model.FullInvoiceEntity
import com.example.data.model.SimpleEstimateEntity
import kotlinx.coroutines.flow.Flow

class InvoiceRepository(private val invoiceDao: InvoiceDao) {
    val allFullInvoices: Flow<List<FullInvoiceEntity>> = invoiceDao.getAllFullInvoices()
    val allSimpleEstimates: Flow<List<SimpleEstimateEntity>> = invoiceDao.getAllSimpleEstimates()

    suspend fun getFullInvoiceById(id: Long) = invoiceDao.getFullInvoiceById(id)
    suspend fun saveFullInvoice(invoice: FullInvoiceEntity) = invoiceDao.insertFullInvoice(invoice)
    suspend fun deleteFullInvoice(id: Long) = invoiceDao.deleteFullInvoiceById(id)

    suspend fun getSimpleEstimateById(id: Long) = invoiceDao.getSimpleEstimateById(id)
    suspend fun saveSimpleEstimate(estimate: SimpleEstimateEntity) = invoiceDao.insertSimpleEstimate(estimate)
    suspend fun deleteSimpleEstimate(id: Long) = invoiceDao.deleteSimpleEstimateById(id)
}
