package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.EstimateItem
import com.example.data.model.InvoiceItem
import com.example.util.IndianCurrencyWordConverter
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Progoti Invoice", appName)
    }

    @Test
    fun `test indian currency words converter`() {
        assertEquals("Zero", IndianCurrencyWordConverter.convert(0.0))
        assertEquals("One Thousand Two Hundred Fifty Only", IndianCurrencyWordConverter.convert(1250.0))
        assertEquals("Fifty Three Thousand Forty Only", IndianCurrencyWordConverter.convert(53040.0))
        assertEquals("One Lakh Five Hundred Only", IndianCurrencyWordConverter.convert(100500.0))
    }

    @Test
    fun `test invoice item amount calculation`() {
        val item = InvoiceItem(quantity = "10", rate = "25.50")
        assertEquals(255.0, item.calculateAmount(), 0.001)

        val emptyItem = InvoiceItem(quantity = "", rate = "10")
        assertEquals(0.0, emptyItem.calculateAmount(), 0.001)
    }

    @Test
    fun `test estimate item amount calculation`() {
        val item = EstimateItem(quantity = "4", rate = "125.00")
        assertEquals(500.0, item.calculateAmount(), 0.001)
    }
}
